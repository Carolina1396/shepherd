"""DailyMed SPL acquisition — real fetcher behind the :class:`Fetcher` protocol.

Idempotent and content-addressed (BLAKE3 manifest + checksums), recording source provenance
(URL / ETag / Last-Modified) into the artifact manifest. Downloads the DailyMed full-release
index + release ZIPs using **stdlib ``urllib`` only** (no ``requests``), streaming each release
into the content-addressed store. Re-ingesting an identical release is a cache hit; conditional
GET (``If-None-Match`` / ``If-Modified-Since``) skips bytes the server confirms unchanged.

Freshness-gated: DailyMed replaces its fixed-name full-release ZIPs **in place** for every new
release, so conditional GET legitimately re-downloads tens of GB whenever NLM cuts a new
snapshot. To bound that, a stored release fetched within ``dailymed_max_age_days`` (run param,
default **7**) is reused with **zero network I/O** for its ZIP — the cached release is
re-expanded into its SPL members exactly like the HTTP-304 path. The gate keys off the
``retrieved_at`` recorded in the release ZIP's manifest (no extra requests); a release is at
most one window stale. ``force`` (run param) bypasses the gate; ``dailymed_max_age_days <= 0``
disables it (always re-check via conditional GET). A release listed in the index but 404 on
the server (NLM publishes the listing before/without every S3 object) first falls back to its
stale cached copy, else is skipped; skipped releases are bounded by the declared-corpus
coverage floor (:data:`_MISSING_FILE_TOLERANCE`), so a broken tail shard degrades gracefully
while a missing multi-GB part fails loudly. Each
release ZIP's SPL XML members are extracted and ingested individually (the SPL extractor reads
``.xml``/``.xml.gz``, not ZIPs), mirroring the legacy ``getFullRelease.pl`` "extract XMLs into
``xmls/<bin>/...xml.gz``" step. ``release_limit`` (run param) bounds how many releases a bounded
run processes. Offline tests monkeypatch the module-level ``fetch`` / the stdlib ``urlopen`` seam.

The legacy ``ref/legacy/DailyMed/bin/getFullRelease.pl`` is intentionally **not** replicated: it
destructively stashed whole download directories (``rm -r $ddir.prev``; ``mv $ddir
$ddir.prev``) before re-fetching. This fetcher never moves or deletes shared state — it
only ever *adds* immutable, content-addressed artifacts and overwrites human-readable
aliases in place.

``fetch = DailyMedFetcher().fetch`` is exposed at module scope so tests can
``monkeypatch.setattr(dailymed, "fetch", ...)``. The internal ``_download_full_release``
is also module-level so wiring tests can stub it (no real network in CI).
"""

from __future__ import annotations

import http
import io
import json
import re
import shutil
import time
import urllib.error
import urllib.request
import zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from pathlib import Path

from dakp_pipeline.io.artifact_store import ArtifactStore
from dakp_pipeline.io.contracts import ArtifactRef, TaskContext
from dakp_pipeline.io.manifests import SourceBlock
from dakp_pipeline.io.xcom import REFS_FILE_MEDIA_TYPE, refs_to_xcom
from dakp_pipeline.logging_setup import logger, progress, stats, step
from dakp_pipeline.paths import Workdir

# DailyMed "all drug labels" full-release listing (legacy getFullRelease.pl target).
FULL_RELEASE_INDEX_URL = "https://dailymed.nlm.nih.gov/dailymed/spl-resources-all-drug-labels.cfm"
#: Default freshness window (days): a stored release younger than this is reused, no download.
_DEFAULT_MAX_AGE_DAYS = 7.0
# Anchors the parser to the "Full Releases" section of the index page.
_FULL_RELEASES_HEADING = "Full Releases"
# Matches release ZIP hrefs as written by the DailyMed index page, e.g.
#   <a href="https://dailymed-data.nlm.nih.gov/public-release-files/dm_spl_release_human_rx_part1.zip">
_RELEASE_ZIP_HREF = re.compile(r'href="(?P<url>https?://[^"]+\.zip)"', re.IGNORECASE)

_DOWNLOAD_TIMEOUT = 60.0
#: Max concurrent release downloads/cache checks within one DailyMed acquisition.
_DOWNLOAD_CONCURRENCY = 4
#: Tolerated share of the index-declared SPL corpus that may vanish (404 releases) before the
#: acquisition fails loudly. NLM's index can advertise a ZIP S3 no longer holds (observed: the
#: September 2026 cut listed a 35-file ``human_otc_part12`` tail shard the bucket never got),
#: so a sliver of declared files is skippable while a missing multi-GB part (~5% of the corpus)
#: still fails instead of silently building a hollow corpus.
_MISSING_FILE_TOLERANCE = 0.01
#: Fallback floor when the index declares no per-release file counts (layout drift): at most
#: this many 404 releases are tolerated when coverage cannot be measured.
_MAX_MISSING_RELEASES = 2
_CHUNK = 1 << 20  # 1 MiB streaming window.
#: Narration prefix for every log line this fetcher emits (one stat per line).
_EVENT = "acquire_dailymed"
#: One INFO progress line per this many ingested SPL documents (per-document detail is DEBUG).
_SPL_PROGRESS_EVERY = 2500
#: Store alias of the single JSON file the DAG's ``acquire_dailymed`` task publishes the full SPL
#: member refs list through (the single-file XCom handoff — see :func:`write_refs_manifest`).
_REFS_ALIAS = "dailymed/spl-refs.json"


class DailyMedFetcher:
    """Acquire DailyMed SPL full-release artifacts over the network (stdlib only)."""

    def fetch(self, ctx: TaskContext) -> list[ArtifactRef]:
        return _download_full_release(ctx)


fetch = DailyMedFetcher().fetch


def _download_full_release(ctx: TaskContext) -> list[ArtifactRef]:
    """Download the DailyMed full release into the content-addressed store.

    Idempotent and non-destructive: each release ZIP is streamed to a workdir-local
    staging file, then :meth:`ArtifactStore.ingest` copies it into ``by-hash/<hex>/``
    (cache hit if identical). The staging file is removed after ingest; shared state is
    never renamed or deleted. Conditional headers skip bytes the server reports unchanged.
    """
    with step(logger, _EVENT):
        store = ArtifactStore(Workdir(ctx.workdir))
        staging = Workdir(ctx.workdir).root / ".staging" / "dailymed"
        staging.mkdir(parents=True, exist_ok=True)

        index_html = _fetch_index(ctx, staging, store)
        release_urls = _apply_release_limit(_parse_release_zips(index_html), ctx)
        declared_counts = _parse_declared_file_counts(index_html)
        stats(logger, _EVENT, releases_discovered=len(release_urls))
        if not release_urls:
            msg = "no DailyMed full-release ZIPs found in index (the listing page layout may have changed)"
            raise RuntimeError(msg)

        max_age_days = _max_age_days(ctx)
        force = bool(ctx.params.get("force", False))
        with ThreadPoolExecutor(max_workers=min(_DOWNLOAD_CONCURRENCY, len(release_urls))) as pool:
            futures = [pool.submit(_download_one, url, staging, store, max_age_days=max_age_days, force=force) for url in release_urls]
            # Collect in index order even when releases finish out of order.
            outcomes = [future.result() for future in futures]
        refs = [ref for out_refs, _missing in outcomes for ref in out_refs]
        missing_urls = [url for url, (_out_refs, missing) in zip(release_urls, outcomes, strict=True) if missing]
        _enforce_release_coverage(missing_urls, declared_counts)
        stats(logger, _EVENT, spl_artifacts_acquired=len(refs))
        return refs


def _enforce_release_coverage(missing_urls: list[str], declared_counts: dict[str, int]) -> None:
    """Fail loudly when 404-skipped releases hollow out more than a sliver of the corpus.

    Tolerance is measured against the per-release file counts the index itself declares
    (:func:`_parse_declared_file_counts`): a broken tail shard (a handful of files) degrades
    gracefully, while a missing multi-GB part — or wholesale bucket breakage — fails the
    acquisition. When the missing releases carry no declared counts (layout drift), the floor
    falls back to an absolute release count because coverage cannot be measured.
    """
    if not missing_urls:
        return
    missing_names = [url.rsplit("/", 1)[-1] for url in missing_urls]
    undeclared = [url for url in missing_urls if url not in declared_counts]
    declared_total = sum(declared_counts.values())
    if declared_total > 0 and not undeclared:
        declared_missing = sum(declared_counts[url] for url in missing_urls)
        coverage_loss = declared_missing / declared_total
        stats(
            logger,
            _EVENT,
            releases_missing=len(missing_urls),
            missing_files_declared=declared_missing,
            declared_files_total=declared_total,
            coverage_loss=round(coverage_loss, 6),
        )
        if coverage_loss > _MISSING_FILE_TOLERANCE:
            msg = (
                f"DailyMed releases listed in the index but 404 on the server exceed the coverage floor: "
                f"{', '.join(missing_names)} = {declared_missing}/{declared_total} declared files "
                f"({coverage_loss:.1%} > {_MISSING_FILE_TOLERANCE:.1%}); refusing to build a hollow corpus"
            )
            raise RuntimeError(msg)
        return
    stats(logger, _EVENT, releases_missing=len(missing_urls), undeclared_missing=len(undeclared), declared_releases=len(declared_counts))
    if len(missing_urls) > _MAX_MISSING_RELEASES:
        drift = (
            "the index declares no per-release file counts"
            if not declared_counts
            else f"{len(undeclared)} of the missing releases carry no declared file counts (index layout drift?)"
        )
        msg = (
            f"DailyMed releases listed in the index but 404 on the server exceed the fallback floor: "
            f"{', '.join(missing_names)} ({len(missing_urls)} > {_MAX_MISSING_RELEASES}); {drift}, "
            f"so coverage cannot be measured"
        )
        raise RuntimeError(msg)


def write_refs_manifest(ctx: TaskContext, refs: list[ArtifactRef]) -> ArtifactRef:
    """Persist the acquired SPL member refs as ONE JSON artifact; return its sentinel ref.

    The acquisition yields one ref per SPL member (tens of thousands across all releases);
    pushing that list inline as the task's XCom result stalls the Airflow Execution API
    (ReadTimeouts under real data). Instead the full list — in the exact :func:`refs_to_xcom`
    shape, the Python<->Go contract — is written to a single JSON file, content-addressed into
    the store under :data:`_REFS_ALIAS`, and only that file's ref (marked with the
    ``REFS_FILE_MEDIA_TYPE`` sentinel) crosses XCom. Consumers resolve the sentinel back to the
    full list (:func:`dakp_pipeline.io.xcom.refs_from_xcom`; the Go ``DecodeArtifactRefs``
    mirror). Every acquisition path (fresh download, 304 re-expansion, cached-refs fast path)
    funnels through here at the DAG boundary; identical refs are a store cache hit, so re-runs
    stay idempotent.
    """
    store = ArtifactStore(Workdir(ctx.workdir))
    staging = Workdir(ctx.workdir).root / ".staging" / "dailymed" / "spl-refs.json"
    staging.parent.mkdir(parents=True, exist_ok=True)
    staging.write_text(json.dumps(refs_to_xcom(refs), indent=2), encoding="utf-8")
    ref, cache_hit = store.ingest(staging, alias=_REFS_ALIAS, media_type=REFS_FILE_MEDIA_TYPE)
    staging.unlink(missing_ok=True)
    stats(logger, _EVENT, refs_file=str(ref.uri), spl_refs=len(refs), cache_hit=cache_hit)
    return ref


def _fetch_index(ctx: TaskContext, staging: Path, store: ArtifactStore) -> str:
    """Fetch (and cache) the full-release index HTML, returning its text.

    On HTTP 304 the previously cached store copy is read instead of re-downloading.
    """
    alias = "dailymed/spl-resources-all-drug-labels.html"
    dest = staging / "spl-resources-all-drug-labels.html"
    source = _prior_source(store, alias=alias)
    index_event = f"{_EVENT} index"
    stats(logger, index_event, url=FULL_RELEASE_INDEX_URL)
    started = time.monotonic()
    etag, last_modified = _conditional_download(FULL_RELEASE_INDEX_URL, dest, source)
    if not dest.exists():
        cached = store.cached_ref(alias)
        if cached is None:
            msg = "server returned 304 for the DailyMed index but no cached copy exists"
            raise RuntimeError(msg)
        stats(logger, index_event, cache_fresh=True)
        return cached.uri.read_text(encoding="utf-8", errors="replace")
    stats(logger, index_event, bytes=dest.stat().st_size, elapsed_s=round(time.monotonic() - started, 3))
    store.ingest(dest, alias=alias, source=SourceBlock(url=FULL_RELEASE_INDEX_URL, etag=etag, last_modified=last_modified, retrieved_at=_now_iso()))
    text = dest.read_text(encoding="utf-8", errors="replace")
    dest.unlink(missing_ok=True)
    return text


def _parse_release_zips(index_html: str) -> list[str]:
    """Return the ordered, de-duplicated full-release ZIP URLs from the index page.

    Only links appearing after the ``Full Releases`` heading are kept, mirroring the
    legacy Perl parser's section scan.
    """
    matches, _section = _release_zip_matches(index_html)
    urls: list[str] = []
    seen: set[str] = set()
    for match in matches:
        url = match.group("url")
        if url not in seen:
            seen.add(url)
            urls.append(url)
    return urls


def _release_zip_matches(index_html: str) -> tuple[list[re.Match[str]], str]:
    """The release-ZIP href matches (in order) plus the section they were found in."""
    head = index_html.find(_FULL_RELEASES_HEADING)
    section = index_html[head:] if head != -1 else index_html
    return list(_RELEASE_ZIP_HREF.finditer(section)), section


#: ``Number of files`` bullet the index publishes per release ZIP (its declared file count).
_DECLARED_FILES = re.compile(r"Number of files:?\s*</strong>\s*([\d,]+)", re.IGNORECASE)


def _parse_declared_file_counts(index_html: str) -> dict[str, int]:
    """Per-release SPL file counts the index declares next to each release link.

    The index page publishes a small manifest per release ZIP (file count, size, MD5). The
    counts give acquisition a coverage denominator, so a skipped release can be judged by the
    share of the corpus it represents instead of guessed at (:func:`_enforce_release_coverage`).
    Best-effort: a release without an adjacent count is simply absent from the mapping.
    """
    matches, section = _release_zip_matches(index_html)
    counts: dict[str, int] = {}
    for i, match in enumerate(matches):
        chunk_end = matches[i + 1].start() if i + 1 < len(matches) else len(section)
        declared = _DECLARED_FILES.search(section, match.end(), chunk_end)
        if declared is not None:
            counts[match.group("url")] = int(declared.group(1).replace(",", ""))
    return counts


def _download_one(
    url: str, staging: Path, store: ArtifactStore, *, max_age_days: float | None = None, force: bool = False
) -> tuple[list[ArtifactRef], bool]:
    """Download one release ZIP and ingest its SPL XML members; ``(refs, missing)``.

    ``missing=True`` marks a release that is listed in the index but 404 on the server (NLM's
    index can advertise a ZIP S3 no longer holds); the caller weighs skipped releases against
    the declared-corpus coverage floor (:func:`_enforce_release_coverage`).

    Freshness gate first: unless ``force`` (or ``max_age_days`` is ``None``), a release whose
    stored copy is younger than ``max_age_days`` skips the network entirely — the cached ZIP is
    re-expanded into its SPL members exactly like the HTTP-304 path. That gate is what stops a
    full re-download every time NLM cuts a new release (fixed-name ZIPs replaced in place).

    The release ZIP is recorded under its ``dailymed/<name>`` alias (provenance anchor +
    conditional-GET source for future runs), then its SPL XML members are extracted and
    ingested individually — those ``.xml``/``.xml.gz`` refs are what the SPL extractor
    consumes. On HTTP 304 the cached release ZIP is re-expanded into its SPL members (no
    re-download), so a re-run yields the same SPL refs the extractor needs; returns ``[]`` only
    if a 304 occurs with no cached copy resolvable. On 404, a stale cached copy (however old)
    is reused instead of nothing before the release is given up on.
    """
    name = url.rsplit("/", 1)[-1]
    alias = f"dailymed/{name}"
    dest = staging / name
    out_dir = staging / f"{name}-xml"
    release_event = f"{_EVENT} release"
    stats(logger, release_event, release=name)
    stats(logger, release_event, level="DEBUG", url=url)
    gate_started = time.monotonic()
    if not force and max_age_days is not None:
        age = _release_age_days(store, alias)
        if age is not None and age < max_age_days:
            cached = store.cached_ref(alias)
            if cached is not None and cached.uri.exists():
                refs = store.cached_refs(alias, cached.blake3)
                if refs is not None:
                    stats(logger, release_event, fresh_skip=True, cache_hit=True, age_days=round(age, 2), max_age_days=max_age_days)
                    stats(logger, release_event, spl_documents_ingested=len(refs), elapsed_s=round(time.monotonic() - gate_started, 3))
                    return refs, False
                stats(logger, release_event, fresh_skip=True, cache_members_missing=True)
                refs = _expand_release_zip(
                    cached.uri,
                    out_dir,
                    store,
                    SourceBlock(url=url, retrieved_at=_now_iso()),
                    release_name=name,
                    release_alias=alias,
                    release_artifact_id=cached.blake3,
                )
                stats(logger, release_event, spl_documents_ingested=len(refs), elapsed_s=round(time.monotonic() - gate_started, 3))
                return refs, False
    source = _prior_source(store, alias=alias)
    started = time.monotonic()
    try:
        etag, last_modified = _conditional_download(url, dest, source)
    except urllib.error.HTTPError as exc:
        if exc.code != http.HTTPStatus.NOT_FOUND:
            raise
        exc.close()
        stats(logger, release_event, release_missing=True, http_status=exc.code)
        # Best effort before skipping: a stale cached copy (however old) beats a hole in the
        # corpus, mirroring what an expired gate or a 304 would have served.
        cached = store.cached_ref(alias)
        if cached is not None and cached.uri.exists():
            stale_age = _release_age_days(store, alias)
            refs = store.cached_refs(alias, cached.blake3)
            if refs is None:
                refs = _expand_release_zip(
                    cached.uri,
                    out_dir,
                    store,
                    SourceBlock(url=url, retrieved_at=_now_iso()),
                    release_name=name,
                    release_alias=alias,
                    release_artifact_id=cached.blake3,
                )
            stats(
                logger,
                release_event,
                stale_fallback=True,
                stale_age_days=None if stale_age is None else round(stale_age, 2),
                spl_documents_ingested=len(refs),
                elapsed_s=round(time.monotonic() - gate_started, 3),
            )
            if stale_age is not None and max_age_days is not None and stale_age > max_age_days:
                logger.warning(
                    "{}: release {} is 404 upstream; serving the cached copy from {:.1f} days ago (freshness window {:.1f} days)",
                    _EVENT,
                    name,
                    stale_age,
                    max_age_days,
                )
            return refs, False
        logger.warning("{}: release {} is listed in the index but 404 on the server; skipped (coverage floor applies)", _EVENT, name)
        return [], True
    if not dest.exists():
        # 304 Not Modified: the cached release ZIP is still current — re-expand it into its SPL XML
        # members (no re-download). The SPL extractor consumes the .xml/.xml.gz refs, not the ZIP.
        stats(logger, release_event, cache_fresh=True)
        cached = store.cached_ref(alias)
        if cached is None:
            return [], False
        refs = store.cached_refs(alias, cached.blake3)
        if refs is None:
            refs = _expand_release_zip(
                cached.uri,
                out_dir,
                store,
                SourceBlock(url=url, retrieved_at=_now_iso()),
                release_name=name,
                release_alias=alias,
                release_artifact_id=cached.blake3,
            )
        stats(logger, release_event, spl_documents_ingested=len(refs), elapsed_s=round(time.monotonic() - started, 3))
        return refs, False
    stats(logger, release_event, bytes=dest.stat().st_size, elapsed_s=round(time.monotonic() - started, 3))
    src_block = SourceBlock(url=url, etag=etag, last_modified=last_modified, retrieved_at=_now_iso())
    ref, cache_hit = store.ingest(dest, alias=alias, source=src_block)
    stats(logger, release_event, blake3=ref.blake3, cache_hit=cache_hit)
    refs = _expand_release_zip(dest, out_dir, store, src_block, release_name=name, release_alias=alias, release_artifact_id=ref.blake3)
    dest.unlink(missing_ok=True)  # staged zip no longer needed once its XMLs are content-addressed
    stats(logger, release_event, spl_documents_ingested=len(refs), elapsed_s=round(time.monotonic() - started, 3))
    return refs, False


def _apply_release_limit(urls: list[str], ctx: TaskContext) -> list[str]:
    """Slice to the first N full releases when ``release_limit`` is set (<=0 / None = all).

    Bounds a run to a tiny real DailyMed scope (e.g. ``release_limit=1`` via the integration test
    harness, as the offline smoke test does), mirroring FAERS ``quarter_limit``.
    """
    limit = ctx.params.get("release_limit")
    if not isinstance(limit, int) or limit <= 0:
        return urls
    return urls[:limit]


def _expand_release_zip(
    zip_path: Path, out_dir: Path, store: ArtifactStore, source: SourceBlock, *, release_name: str, release_alias: str, release_artifact_id: str
) -> list[ArtifactRef]:
    """Ingest the SPL XML documents of a DailyMed release ZIP as individual artifacts.

    DailyMed full-release ZIPs are nested: the outer archive holds one ``.zip`` per SPL document
    (e.g. ``prescription/<date>_<uuid>.zip``), and each inner archive holds that document's
    ``.xml`` (plus media we ignore). The SPL extractor reads ``.xml``/``.xml.gz`` (not ZIPs), so
    this descends into each per-document ZIP and content-addresses the SPL XML inside under
    ``dailymed/<release>::<member>`` with the release's source provenance. A top-level
    ``.xml``/``.xml.gz`` member (older release layouts) is ingested directly. Non-SPL members are
    skipped; a release yielding no SPL documents returns ``[]`` (logged) rather than failing the
    whole acquisition. Extracted members are staged under ``out_dir`` (caller-owned scratch).
    """
    expansion_event = f"{_EVENT} expansion"
    out_dir.mkdir(parents=True, exist_ok=True)
    store.invalidate_cached_refs(release_alias)
    refs: list[ArtifactRef] = []
    member_aliases: list[str] = []
    with zipfile.ZipFile(zip_path) as archive:
        members = [info for info in archive.infolist() if not info.is_dir()]
        total = sum(1 for info in members if _looks_like_spl_target(Path(info.filename).name))
        stats(logger, expansion_event, release=release_name, spl_targets=total)
        done = 0
        for info in members:
            name = Path(info.filename).name
            if name.lower().endswith(".zip"):
                # Nested per-document archive: ingest the SPL XML it contains.
                ingested = _expand_doc_zip(archive.read(info), out_dir, store, source, release_name=release_name, member_aliases=member_aliases)
                refs.extend(ingested)
                done += len(ingested)
            elif _looks_like_spl_name(name):
                refs.append(
                    _ingest_spl_bytes(archive.read(info), name, out_dir, store, source, release_name=release_name, member_aliases=member_aliases)
                )
                done += 1
            progress(logger, expansion_event, done, total, every=_SPL_PROGRESS_EVERY)
    store.write_cached_refs(release_alias, release_artifact_id, member_aliases)
    if not refs:
        logger.warning("{}: release {} contained no SPL XML members", _EVENT, release_name)
    return refs


def _expand_doc_zip(
    doc_bytes: bytes, out_dir: Path, store: ArtifactStore, source: SourceBlock, *, release_name: str, member_aliases: list[str]
) -> list[ArtifactRef]:
    """Ingest the SPL XML member(s) of one nested per-document DailyMed ZIP (held in memory)."""
    refs: list[ArtifactRef] = []
    with zipfile.ZipFile(io.BytesIO(doc_bytes)) as doc_archive:
        for info in doc_archive.infolist():
            if info.is_dir():
                continue
            member = Path(info.filename).name
            if _looks_like_spl_name(member):
                refs.append(
                    _ingest_spl_bytes(
                        doc_archive.read(info), member, out_dir, store, source, release_name=release_name, member_aliases=member_aliases
                    )
                )
    return refs


def _ingest_spl_bytes(
    data: bytes, member: str, out_dir: Path, store: ArtifactStore, source: SourceBlock, *, release_name: str, member_aliases: list[str]
) -> ArtifactRef:
    """Write one SPL member to staging and content-address it under the release alias.

    A flat ``::<member>`` alias (not nested under the release) never collides with the release
    ZIP's own ``dailymed/<release>`` alias file; per-document SPL names are UUIDs, so they are
    unique within a release.
    """
    target = out_dir / member
    target.write_bytes(data)
    alias = f"dailymed/{release_name}::{member}"
    ref, _ = store.ingest(target, alias=alias, source=source)
    member_aliases.append(alias)
    target.unlink(missing_ok=True)
    return ref


def _looks_like_spl_name(name: str) -> bool:
    """Whether a release member is an SPL document the extractor can read."""
    return name.lower().endswith((".xml.gz", ".xml"))


def _looks_like_spl_target(name: str) -> bool:
    """Whether a release member can yield SPL documents (a nested doc zip or an SPL file)."""
    return name.lower().endswith((".zip", ".xml.gz", ".xml"))


def _conditional_download(url: str, dest: Path, source: SourceBlock | None) -> tuple[str | None, str | None]:
    """Stream ``url`` to ``dest`` with conditional headers; return (etag, last_modified).

    On HTTP 304 the destination is left absent and ``(None, None)`` is returned so the
    caller treats the artifact as cache-fresh. Any other HTTP error is raised. A stale
    staging file is removed before the request so it can never masquerade as fresh.

    Deliberately NOT routed through the aria2c downloader (unlike FAERS / Drugs@FDA): this path
    needs fine-grained 304 / ETag / Last-Modified handling the 7-day freshness gate depends on,
    and aria2c would both double the request count and discard the provenance headers recorded
    back into the manifest.
    """
    headers: dict[str, str] = {}
    if source is not None:
        if source.etag:
            headers["If-None-Match"] = source.etag
        if source.last_modified:
            headers["If-Modified-Since"] = source.last_modified
    dest.unlink(missing_ok=True)  # never let a stale staging file masquerade as fresh
    request = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=_DOWNLOAD_TIMEOUT) as resp:
            etag = resp.headers.get("ETag")
            last_modified = resp.headers.get("Last-Modified")
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open("wb") as handle:
                shutil.copyfileobj(resp, handle, length=_CHUNK)
            return etag, last_modified
    except urllib.error.HTTPError as exc:
        if exc.code == http.HTTPStatus.NOT_MODIFIED:
            exc.close()
            return None, None
        raise


def _prior_source(store: ArtifactStore, *, alias: str) -> SourceBlock | None:
    """Read the source block previously recorded for ``alias`` (for conditional GET)."""
    alias_path = Workdir(store.workdir.root).aliases / alias
    if not alias_path.exists():
        return None
    artifact_id = alias_path.read_text(encoding="utf-8").strip()
    manifest = store.read_manifest(artifact_id)
    return manifest.source if manifest is not None else None


def _max_age_days(ctx: TaskContext) -> float | None:
    """Resolve the release freshness window (days) from run params.

    Absent/``None`` ⇒ the default window (:data:`_DEFAULT_MAX_AGE_DAYS`); a non-numeric or
    ``<= 0`` value disables the gate (every run re-checks via conditional GET).
    """
    value = ctx.params.get("dailymed_max_age_days")
    if value is None:
        return _DEFAULT_MAX_AGE_DAYS
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if value > 0 else None


def _release_age_days(store: ArtifactStore, alias: str, *, now: datetime | None = None) -> float | None:
    """Age of the release stored under ``alias`` in days, or ``None`` when not reusable.

    ``None`` (callers treat it as stale and fall through to the conditional-GET flow) when the
    alias or the cached ZIP is absent, or the manifest's ``source.retrieved_at`` is missing or
    not parseable against an aware timestamp.
    """
    cached = store.cached_ref(alias)
    if cached is None or not cached.uri.exists():
        return None
    manifest = store.read_manifest(cached.blake3)
    if manifest is None or not manifest.source.retrieved_at:
        return None
    try:
        retrieved_at = datetime.fromisoformat(manifest.source.retrieved_at)
        age = (now if now is not None else datetime.now(UTC)) - retrieved_at
    except (TypeError, ValueError):
        return None
    return age.total_seconds() / 86400.0


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


__all__ = ["FULL_RELEASE_INDEX_URL", "DailyMedFetcher", "fetch", "write_refs_manifest"]
