"""Acquisition-task tests — offline (monkeypatched HTTP), import-safe WITHOUT airflow.

The Airflow acquisition tasks in :mod:`dakp_pipeline.dags.dakp_build` delegate to the shared
:mod:`dakp_pipeline.acquire` layer, so these tests exercise the task callables directly via
that layer (no network, no airflow needed). The Airflow task-graph assertions run only when
apache-airflow is importable and are skipped otherwise.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from dakp_pipeline import acquire, runtime
from dakp_pipeline.io.contracts import ArtifactRef, TaskContext
from dakp_pipeline.paths import Workdir
from dakp_pipeline.sources import canada_vigilance, dailymed, drugsfda, ema, ema_documents, ema_smpc, faers

_FIXTURE_ROOT = Path(__file__).resolve().parents[1] / "fixtures" / "pipeline"


def _ctx(workdir: Path, *, params: dict[str, object] | None = None) -> TaskContext:
    Workdir(workdir).create()
    return TaskContext(workdir=workdir, fixture_root=_FIXTURE_ROOT, params=dict(params or {}))


# --- source acquisition helpers delegate to the real fetchers -------------------


@pytest.mark.parametrize(
    ("helper", "module"),
    [
        (acquire.acquire_dailymed, dailymed),
        (acquire.acquire_faers, faers),
        (acquire.acquire_drugsfda, drugsfda),
        (acquire.acquire_ema, ema),
        (acquire.acquire_canada_vigilance, canada_vigilance),
    ],
    ids=["dailymed", "faers", "drugsfda", "ema", "canada_vigilance"],
)
def test_acquire_source_helpers_delegate_to_fetcher(helper, module, monkeypatch, tmp_path: Path) -> None:
    calls: list[TaskContext] = []

    def fake_fetch(ctx: TaskContext) -> list[ArtifactRef]:
        calls.append(ctx)
        return [ArtifactRef(uri=tmp_path / "raw.bin", blake3="b3:deadbeef", media_type="application/octet-stream")]

    monkeypatch.setattr(module, "fetch", fake_fetch)
    ctx = _ctx(tmp_path, params={"quarter_limit": 2})

    refs = helper(ctx)

    # The fetcher received the exact context (params included) and its manifest is returned.
    assert calls == [ctx]
    assert calls[0].params["quarter_limit"] == 2
    assert [ref.blake3 for ref in refs] == ["b3:deadbeef"]


def test_acquire_ema_smpc_returns_documents_report_first_then_pdfs(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """The extract task requires the documents-report JSON among its inputs; acquire must hand it over.

    The 2026-10-06 production build failed ``extract_ema_smpc`` with "no EMA documents report
    (json) among the inputs" because the DAG fed it only the crawl's PDF refs. The report ref
    comes FIRST, then the crawl refs in selection order, and ``extract`` consumes exactly that
    list end to end.
    """
    ctx = _ctx(tmp_path)
    report_src = _FIXTURE_ROOT / "ema" / "epar_documents_en.json"
    pdf_src = _FIXTURE_ROOT / "ema" / "smpc" / "ceplene-epar-product-information_en.pdf"
    report = ArtifactRef(uri=report_src, blake3="b3:report", media_type="application/json")
    pdf = ArtifactRef(uri=pdf_src, blake3="b3:pdf", media_type="application/pdf")
    monkeypatch.setattr(ema_documents, "fetch", lambda c: [report])
    monkeypatch.setattr(ema_smpc, "fetch", lambda c: [pdf])

    refs = acquire.acquire_ema_smpc(ctx)

    assert refs == [report, pdf]

    # The wiring contract: extract accepts the acquire output verbatim and attributes the PDF
    # via the report (a real pypdf parse of the committed fixture PDF).
    from dakp_pipeline.extract import ema_smpc as extract_ema_smpc

    extracted = extract_ema_smpc.extract(refs, ctx)
    assert extracted, "extract must produce the sections/warnings artifacts"
    assert all(ref.uri.exists() for ref in extracted)


# --- Canada Vigilance download identity -----------------------------------------


def test_canada_vigilance_download_identifies_as_curl(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Canada's Akamai edge stalls the pipeline UA; the ZIP fetch must present ``curl/8.x``.

    The 2026-10-06 production build hung ~10 minutes transferring 0 bytes with
    ``dakp-pipeline/0.1`` and the urllib fallback then read-timed out, failing the DAG run.
    """
    captured: list[dict[str, str]] = []

    def fake_download(url: str, dest: Path, *, timeout: float = 120.0, headers: dict[str, str] | None = None) -> Path:
        captured.append(dict(headers or {}))
        dest.write_bytes(b"PK\x03\x04")
        return dest

    monkeypatch.setattr(canada_vigilance, "download", fake_download)
    canada_vigilance.download_canada_vigilance_zip("https://example.test/extract_extrait.zip", tmp_path / "cv.zip")

    assert captured == [{"User-Agent": "curl/8.10.1"}]


# --- NER model acquisition ------------------------------------------------------


def test_acquire_ner_models_downloads_and_is_idempotent(tmp_path: Path) -> None:
    calls: list[str] = []

    def fake_downloader(model_id: str, dest: Path) -> None:
        calls.append(model_id)
        (dest / "model.bin").write_bytes(b"weights")

    ctx = _ctx(tmp_path)
    first = acquire.acquire_ner_models(ctx, models=["fake/model"], downloader=fake_downloader)

    assert len(first) == 1
    ref = first[0]
    assert ref.blake3.startswith("b3:")
    assert ref.media_type == "application/x-directory"
    assert ref.uri.is_dir()
    assert ref.manifest is not None
    assert ref.manifest.exists()
    assert calls == ["fake/model"]

    # Cache hit: identical content tree hash -> no re-download.
    second = acquire.acquire_ner_models(ctx, models=["fake/model"], downloader=fake_downloader)
    assert second[0].blake3 == ref.blake3
    assert calls == ["fake/model"]


def test_acquire_ner_models_force_redownloads(tmp_path: Path) -> None:
    calls: list[str] = []

    def fake_downloader(model_id: str, dest: Path) -> None:
        calls.append(model_id)
        (dest / "model.bin").write_bytes(b"weights")

    ctx = _ctx(tmp_path, params={"force": True})
    acquire.acquire_ner_models(ctx, models=["fake/model"], downloader=fake_downloader)
    acquire.acquire_ner_models(ctx, models=["fake/model"], downloader=fake_downloader)
    assert calls == ["fake/model", "fake/model"]


def test_default_ner_models_is_the_gliner_checkpoint(tmp_path: Path) -> None:
    # With no explicit models= override, acquisition defaults to the GLiNER checkpoint the
    # production NER backend loads (a real run downloads its weights).
    from dakp_pipeline.ner.ner import DEFAULT_MODEL

    assert acquire.default_ner_models(_ctx(tmp_path)) == [DEFAULT_MODEL]


# --- aggregate acquisition ------------------------------------------------------


def test_acquire_all_runs_every_source(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    sentinel = ArtifactRef(uri=tmp_path / "raw.bin", blake3="b3:deadbeef", media_type="application/octet-stream")
    monkeypatch.setattr(dailymed, "fetch", lambda ctx: [sentinel])
    monkeypatch.setattr(faers, "fetch", lambda ctx: [sentinel])
    monkeypatch.setattr(drugsfda, "fetch", lambda ctx: [sentinel])
    monkeypatch.setattr(ema, "fetch", lambda ctx: [sentinel])

    def fake_downloader(model_id: str, dest: Path) -> None:
        (dest / "model.bin").write_bytes(b"weights")

    results = acquire.acquire_all(_ctx(tmp_path), downloader=fake_downloader)
    assert set(results) == {"dailymed", "drugsfda", "ema", "faers", "ner_models"}
    assert results["dailymed"] == [sentinel]
    assert results["drugsfda"] == [sentinel]
    assert results["ema"] == [sentinel]
    assert results["faers"] == [sentinel]
    assert len(results["ner_models"]) == 1  # DEFAULT_MODEL cached via the fake downloader
    assert all(ref.blake3.startswith("b3:") for refs in results.values() for ref in refs)


# --- DAG wiring (import-safe; graph assertions gated on airflow) ----------------


def test_dag_module_importable_and_acquisition_wired(dakp_build) -> None:
    assert dakp_build.DAG_ID == "dakp_pipeline"
    assert dakp_build.DOWNLOAD_POOL == "dakp_download"
    # The acquisition tasks are present in the constructed DAG (they delegate to acquire.*, whose
    # fetcher delegation is covered by test_acquire_source_helpers_delegate_to_fetcher).
    task_ids = {t.task_id for t in dakp_build.dag_obj.tasks}
    assert {"acquire_dailymed", "acquire_faers", "acquire_drugsfda"} <= task_ids


def test_build_context_forwards_drugsfda_url_override(tmp_path: Path) -> None:
    ctx = runtime.build_context_from_config(
        {"workdir": str(tmp_path), "fixture_root": str(_FIXTURE_ROOT), "drugsfda_url": "https://example.test/drugsfda.zip"}
    )
    assert ctx.params["drugsfda_url"] == "https://example.test/drugsfda.zip"


def test_build_context_forwards_fullmap(tmp_path: Path) -> None:
    ctx = runtime.build_context_from_config({"workdir": str(tmp_path), "fixture_root": str(_FIXTURE_ROOT), "fullmap": "/maps/fullmap.redb"})
    assert ctx.params["fullmap"] == "/maps/fullmap.redb"
    # run_tablassert is derived from fullmap presence (a fullmap triggers the real handoff).
    assert ctx.params["run_tablassert"] is True


def test_build_context_forwards_source_max_age_days(tmp_path: Path) -> None:
    ctx = runtime.build_context_from_config(
        {"workdir": str(tmp_path), "fixture_root": str(_FIXTURE_ROOT), "dailymed_max_age_days": 14, "drugsfda_max_age_days": 3, "ema_max_age_days": 5}
    )
    assert ctx.params["dailymed_max_age_days"] == 14.0
    assert ctx.params["drugsfda_max_age_days"] == 3.0
    assert ctx.params["ema_max_age_days"] == 5.0
    # Absent in the config Variable -> None param (the fetchers apply their 7-day defaults).
    ctx = runtime.build_context_from_config({"workdir": str(tmp_path), "fixture_root": str(_FIXTURE_ROOT)})
    assert ctx.params["dailymed_max_age_days"] is None
    assert ctx.params["drugsfda_max_age_days"] is None
    assert ctx.params["ema_max_age_days"] is None


def test_dag_includes_acquisition_tasks_and_pools(dakp_build) -> None:
    dag = dakp_build.dag_obj
    acquire_ids = {
        "acquire_dailymed",
        "acquire_faers",
        "acquire_drugsfda",
        "acquire_ema",
        "acquire_ema_smpc",
        "acquire_canada_vigilance",
        "acquire_ner_models",
    }
    assert acquire_ids <= {t.task_id for t in dag.tasks}

    def upstream(task_id: str) -> set[str]:
        return set(dag.get_task(task_id).upstream_task_ids)

    # The NER acquisition feeds the contraindication miner (download -> mine).
    assert "acquire_ner_models" in upstream("shape_contraindication_tables")

    # Every acquisition task is bounded by the download pool.
    for task_id in acquire_ids:
        assert dag.get_task(task_id).pool == dakp_build.DOWNLOAD_POOL
