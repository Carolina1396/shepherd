"""Edge-case tests for ``dakp_pipeline.ner.ner`` (drive to 100% branch coverage).

Targets the production (GLiNER2) path without network: a fake ``gliner2`` module is injected
into ``sys.modules`` and ``ensure_model`` is stubbed, so ``_load_model``'s successful-import
branch and ``_merge_model_spans`` (gazetteer-wins-on-overlap, type filtering, GLiNER2 recall)
are fully exercised. The fake mirrors gliner2's real result shape
(``{"entities": {label: [{"text", "confidence", "start", "end"}, ...]}}``) -- including
untrimmed offsets around a ``.strip()``ed surface -- as verified against the installed package.
"""

from __future__ import annotations

import sys
import types
from collections.abc import Iterator, Mapping
from contextlib import contextmanager
from dataclasses import FrozenInstanceError
from pathlib import Path
from typing import Any, ClassVar

import pytest
from loguru import logger

from dakp_pipeline.ner import ner as ner_module
from dakp_pipeline.ner.dictionary import OBJECT_TYPES, Gazetteer
from dakp_pipeline.ner.model_cache import ModelRef
from dakp_pipeline.ner.ner import (
    _DEFAULT_WORD_BUDGET,
    _GLINER_TOKEN,
    DEFAULT_MODEL,
    MODEL_LABELS,
    DiseaseNER,
    Mention,
    _cuda_device_supported,
    _install_message,
    _model_device,
    _overlaps_any,
    _sort_key,
    _spans_from_result,
    _strip_aligned,
    _token_budget,
    _trim_hedges,
    _windows,
)

# --- helpers -------------------------------------------------------------------


@contextmanager
def _captured_logs() -> Iterator[list[str]]:
    """Collect rendered loguru lines emitted inside the block (sink removed on exit)."""
    lines: list[str] = []
    sink_id = logger.add(lambda message: lines.append(message.record["message"]), level="DEBUG")
    try:
        yield lines
    finally:
        logger.remove(sink_id)


@contextmanager
def _fake_autocast(device_type: str, **kwargs: Any) -> Iterator[None]:
    """Inert stand-in for ``torch.autocast``; tests that assert the arming replace it."""
    yield


def _install_fake_torch(monkeypatch: pytest.MonkeyPatch) -> Any:
    """Function-scoped fake of the torch surface production code imports lazily: the CUDA
    probe quartet, ``empty_cache``, and the fp16 autocast arming. Installing it in sys.modules
    keeps the real torch -- a multi-second import under coverage tracing, paid once per xdist
    worker by whichever test touches it first -- out of this module's workers, while every
    device-routing branch, exception and assertion below runs UNMODIFIED against the fake.
    ``monkeypatch`` restores the previous sys.modules entry at test end, so real-torch
    consumers elsewhere in the suite (test_logging_setup_edge's spawn child) are unaffected.
    Defaults mirror a CUDA-less CI host; each test pins the probe results it asserts on."""
    torch: Any = types.ModuleType("torch")
    torch.cuda = types.SimpleNamespace(
        is_available=lambda: False, device_count=lambda: 0, get_device_capability=lambda index: (6, 0), get_arch_list=list, empty_cache=lambda: None
    )
    torch.autocast = _fake_autocast
    torch.float16 = "float16"
    monkeypatch.setitem(sys.modules, "torch", torch)
    return torch


@pytest.fixture(autouse=True)
def fake_torch(monkeypatch: pytest.MonkeyPatch) -> Any:
    """Every test in this module runs against _install_fake_torch; request it to pin probes."""
    return _install_fake_torch(monkeypatch)


def test_install_message_names_module_and_command() -> None:
    message = _install_message("gliner2")
    assert "gliner2" in message
    assert "uv sync" in message


# --- _model_device: CUDA when available, CPU fallbacks -------------------------


def test_model_device_selects_cuda_when_available(fake_torch: Any) -> None:
    fake_torch.cuda.is_available = lambda: True
    fake_torch.cuda.get_device_capability = lambda index: (6, 0)
    fake_torch.cuda.get_arch_list = lambda: ["sm_50", "sm_60", "sm_75"]
    assert _model_device() == "cuda"


def test_model_device_falls_back_to_cpu_without_cuda(fake_torch: Any) -> None:
    fake_torch.cuda.is_available = lambda: False
    assert _model_device() == "cpu"


def test_model_device_cpu_when_torch_unimportable(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(sys.modules, "torch", None)  # makes `import torch` raise ImportError
    assert _model_device() == "cpu"


def test_model_device_falls_back_to_cpu_when_arch_unsupported(fake_torch: Any) -> None:
    """CUDA visible but torch has no kernels for the GPU arch (e.g. a cu128 build on a
    P100/sm_60) — CPU instead of crashing on the first CUDA call."""
    fake_torch.cuda.is_available = lambda: True
    fake_torch.cuda.get_device_capability = lambda index: (6, 0)
    fake_torch.cuda.get_arch_list = lambda: ["sm_75", "sm_80"]
    assert _model_device() == "cpu"


# --- _cuda_device_supported: arch-list gate for one device ----------------------


def test_cuda_device_supported_matches_compiled_arch_list(fake_torch: Any) -> None:
    fake_torch.cuda.get_device_capability = lambda index: (6, 0)
    fake_torch.cuda.get_arch_list = lambda: ["sm_60", "sm_75"]
    assert _cuda_device_supported(fake_torch, 0) is True
    fake_torch.cuda.get_arch_list = lambda: ["sm_75", "sm_80"]
    assert _cuda_device_supported(fake_torch, 0) is False


def test_cuda_device_supported_false_when_capability_raises(fake_torch: Any) -> None:
    """A device that errors on capability query counts as unsupported, not a crash."""

    def _raise(index: int) -> tuple[int, int]:
        raise RuntimeError("CUDA driver error")

    fake_torch.cuda.get_device_capability = _raise
    assert _cuda_device_supported(fake_torch, 0) is False


def test_sort_key_and_overlaps_helpers() -> None:
    mention = Mention(text="asthma", start=1, end=7, type="Disease", score=1.0)
    assert _sort_key(mention) == (1, 7, "Disease", "asthma")
    assert _overlaps_any(0, 5, [(3, 8)]) is True
    assert _overlaps_any(0, 3, [(3, 8)]) is False  # touching, not overlapping
    assert _overlaps_any(8, 9, [(3, 8)]) is False
    assert _overlaps_any(0, 5, []) is False


def test_mention_is_frozen() -> None:
    mention = Mention(text="asthma", start=0, end=6, type="Disease", score=1.0)
    with pytest.raises(FrozenInstanceError):
        mention.score = 0.5  # type: ignore[misc]


# --- _load_model: missing dep raises a clear install error ---------------------


def test_load_model_raises_clear_error_without_extra(monkeypatch: pytest.MonkeyPatch) -> None:
    # Block the gliner2 import (None in sys.modules raises ImportError) so the missing-dep
    # branch is exercised deterministically whether or not gliner2 is installed.
    monkeypatch.setitem(sys.modules, "gliner2", None)
    backend = DiseaseNER(offline=False)
    with pytest.raises(ner_module.NERDependencyError, match=r"uv sync"):
        backend.extract("contraindicated in severe hepatic impairment")


# --- _load_model + _merge_model_spans: fake gliner2 (no network) ---------------


def _gliner2_result(predictions: list[dict[str, Any]], window: str) -> dict[str, Any]:
    """Convert flat fake predictions into gliner2's real result shape (window-relative offsets,
    stripped surface text), grouped by label exactly like ``AutoExtractor.extract_entities``.
    Predictions falling outside this window are skipped: the real model only ever returns
    offsets into the text it was given."""
    entities: dict[str, list[dict[str, Any]]] = {}
    for prediction in predictions:
        if prediction["end"] > len(window) or prediction["start"] > prediction["end"]:
            continue
        span = {
            "text": window[prediction["start"] : prediction["end"]].strip(),
            "confidence": prediction["score"],
            "start": prediction["start"],
            "end": prediction["end"],
        }
        entities.setdefault(prediction["label"], []).append(span)
    return {"entities": entities}


class _FakeExtractorModel:
    """Fake gliner2 model exposing the extract_entities / batch_extract_entities API.

    ``entity_types`` is captured VERBATIM, not flattened to its keys: gliner2 accepts a
    ``{label: description}`` mapping there and renders each description into the prompt, so a
    test asserting ``model.calls[i][1] == MODEL_LABELS`` proves the backend still hands over the
    descriptions (a future refactor to names-only would silently degrade extraction quality).
    """

    def __init__(self, predictions: list[dict[str, Any]]) -> None:
        self._predictions = predictions
        self.calls: list[tuple[str, Mapping[str, str], float]] = []

    def extract_entities(
        self,
        text: str,
        entity_types: Mapping[str, str],
        threshold: float = 0.5,
        format_results: bool = True,
        include_confidence: bool = False,
        include_spans: bool = False,
        max_len: int | None = None,
        overlap_policy: str | None = None,
    ) -> dict[str, Any]:
        self.calls.append((text, entity_types, threshold))
        return _gliner2_result(self._predictions, text)

    def batch_extract_entities(
        self,
        texts: list[str],
        entity_types: Mapping[str, str],
        batch_size: int = 8,
        threshold: float = 0.5,
        format_results: bool = True,
        include_confidence: bool = False,
        include_spans: bool = False,
        max_len: int | None = None,
        overlap_policy: str | None = None,
    ) -> list[dict[str, Any]]:
        return [self.extract_entities(text, entity_types, threshold=threshold) for text in texts]


class _FakeAutoExtractor:
    loaded_from: ClassVar[list[str]] = []
    loaded_map_location: ClassVar[list[str]] = []
    model = _FakeExtractorModel([])

    @staticmethod
    def from_pretrained(path: str, map_location: str = "cpu") -> _FakeExtractorModel:
        _FakeAutoExtractor.loaded_from.append(path)
        _FakeAutoExtractor.loaded_map_location.append(map_location)
        return _FakeAutoExtractor.model


def _install_fake_gliner2(monkeypatch: pytest.MonkeyPatch, tmp_path: Path, predictions: list[dict[str, Any]], model: Any = None) -> None:
    _FakeAutoExtractor.loaded_from = []
    _FakeAutoExtractor.loaded_map_location = []
    _FakeAutoExtractor.model = model if model is not None else _FakeExtractorModel(predictions)
    module = types.ModuleType("gliner2")
    module.AutoExtractor = _FakeAutoExtractor  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "gliner2", module)

    def _fake_ensure_model(model_id: str, **kwargs: Any) -> ModelRef:
        return ModelRef(model_id=model_id, source="huggingface", path=tmp_path, b3="b3:deadbeef", manifest=tmp_path / "manifest.json")

    monkeypatch.setattr(ner_module, "ensure_model", _fake_ensure_model)


# --- gliner2 adapter: result flattening + offset strip-alignment ------------------


def test_gliner2_offsets_are_strip_aligned_to_the_span_surface(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """gliner2 ``.strip()``s each span's surface but returns the UNTRIMMED char offsets, so a
    padded prediction would break the mention contract ``text[start:end] == mention.text``.
    The adapter advances start / pulls back end over whitespace to re-align."""

    class _PaddedFakeModel:
        def extract_entities(self, text: str, entity_types: Mapping[str, str], threshold: float = 0.5, **_kwargs: Any) -> dict[str, Any]:
            surface = "asthma"
            start = text.index(surface) - 3  # include leading spaces
            end = text.index(surface) + len(surface) + 2  # include trailing spaces
            return {"entities": {"biolink:Disease": [{"text": surface, "confidence": 0.9, "start": start, "end": end}]}}

    _install_fake_gliner2(monkeypatch, tmp_path, [], model=_PaddedFakeModel())
    text = "in   asthma  and porphyria."
    mentions = DiseaseNER(offline=False, gazetteer={}).extract(text)
    assert [(m.text, m.type) for m in mentions] == [("asthma", "Disease")]
    assert text[mentions[0].start : mentions[0].end] == "asthma"
    assert mentions[0].score == pytest.approx(0.9)


def test_gliner2_whitespace_only_span_is_dropped(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A span whose surface strips to nothing (offsets over pure whitespace) carries no signal;
    it is dropped instead of emitting a zero-width mention."""

    class _WhitespaceSpanFakeModel:
        def extract_entities(self, text: str, entity_types: Mapping[str, str], threshold: float = 0.5, **_kwargs: Any) -> dict[str, Any]:
            start = text.index("   ")
            return {"entities": {"biolink:Disease": [{"text": "", "confidence": 0.9, "start": start, "end": start + 3}]}}

    _install_fake_gliner2(monkeypatch, tmp_path, [], model=_WhitespaceSpanFakeModel())
    assert DiseaseNER(offline=False, gazetteer={}).extract("a   b") == []


def test_spans_from_result_flattens_labels_and_drops_unknown_types() -> None:
    """Direct check of the flattening contract: label keys become canonical types, spans keep
    their confidence as score, and labels outside MENTION_TYPES never surface."""
    window = "  asthma here"
    result = {
        "entities": {
            "biolink:Disease": [{"text": "asthma", "confidence": 0.8, "start": 2, "end": 8}],
            "CHEMICAL": [{"text": "junk", "confidence": 0.9, "start": 9, "end": 13}],
        }
    }
    spans = _spans_from_result(result, window)
    assert [(s.start, s.end, s.type, s.score) for s in spans] == [(2, 8, "Disease", 0.8)]
    assert _spans_from_result({}, window) == []  # a result with no entities key is fine


def test_strip_aligned_trims_both_edges_in_place() -> None:
    """Direct check of the whitespace walker: leading spaces advance start, trailing spaces
    pull back end, and an already-trimmed span is returned untouched."""
    assert _strip_aligned("  asthma  ", 0, 10) == (2, 8)
    assert _strip_aligned("asthma", 0, 6) == (0, 6)
    assert _strip_aligned("     ", 0, 5) == (5, 5)  # fully-whitespace span collapses empty


def test_strip_aligned_clamps_offsets_that_overrun_the_window() -> None:
    """Offsets outside the window are clamped, never indexed.

    gliner2's collator appends a synthetic ``"."`` to any input lacking terminal punctuation and
    builds its char maps from that MUTATED string, so a span ending on the appended period arrives
    as ``end == len(window) + 1``. Indexing the window with it raised
    ``IndexError: string index out of range`` inside a GPU worker — the failure that discarded two
    multi-hour DAG mining shards (runs 8 and 9) with no traceback on disk.
    """
    assert _strip_aligned("asthma", 0, 7) == (0, 6)  # the collator's phantom period
    assert _strip_aligned("asthma", -2, 3) == (0, 3)
    assert _strip_aligned("asthma", 9, 12) == (6, 6)  # wholly past the end collapses empty
    assert _strip_aligned("asthma", 4, 2) == (4, 4)  # inverted span collapses empty


def test_spans_from_result_clamps_an_overrunning_span_and_reports_it() -> None:
    """An over-running span keeps its true surface (the phantom char is not source text) and the
    misalignment is logged once per window; a span wholly past the end is dropped, never emitted
    as a zero-width mention."""
    window = "chronic obstructive pulmonary disease"
    overrun = {"entities": {"biolink:Disease": [{"text": window + ".", "confidence": 0.9, "start": 0, "end": len(window) + 1}]}}
    with _captured_logs() as lines:
        spans = _spans_from_result(overrun, window)
    assert [(span.start, span.end, span.type) for span in spans] == [(0, len(window), "Disease")]
    assert any("ner_span_offsets: clamped = 1" in line for line in lines)

    past_the_end = {"entities": {"biolink:Disease": [{"text": "x", "confidence": 0.9, "start": len(window) + 2, "end": len(window) + 5}]}}
    assert _spans_from_result(past_the_end, window) == []


def test_production_merge_gazetteer_wins_and_gliner_adds_recall(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """The whole adapter contract in one call: category-ID result keys, an out-of-vocabulary label
    dropped, an object span losing to the gazetteer, an out-of-gazetteer object span adding recall,
    a qualifier span routed to its own channel, and the label vocabulary captured verbatim."""
    # "asthma" is in the gazetteer; "porphyria" is out-of-gazetteer (GLiNER recall);
    # "aspirin" is predicted CHEMICAL and must be filtered (outside MENTION_TYPES);
    # "women" carries a qualifier label and must bypass the object-channel population filter;
    # the closed lexical sex match wins the exact-span collision, so one qualifier survives.
    text = "asthma porphyria aspirin in women"
    predictions = [
        {"start": 0, "end": 6, "label": "DISEASE", "score": 0.9},  # overlaps gazetteer 'asthma' -> suppressed
        {"start": 7, "end": 16, "label": "DISEASE", "score": 0.8},  # 'porphyria' -> added (recall)
        {"start": 17, "end": 24, "label": "CHEMICAL", "score": 0.7},  # filtered by vocabulary
        {"start": 28, "end": 33, "label": "biolink:BiologicalSex", "score": 0.9},  # qualifier channel
    ]
    _install_fake_gliner2(monkeypatch, tmp_path, predictions)

    backend = DiseaseNER(
        offline=False, gazetteer={"asthma": "Disease"}, model_id="acme/ner", threshold=0.42, accept_threshold=0.42, cache_dir=tmp_path
    )
    mentions = backend.extract(text)

    assert [(m.text, m.type, m.notes) for m in mentions] == [
        ("asthma", "Disease", "exact"),
        ("porphyria", "Disease", "gliner"),
        ("women", "BiologicalSex", "gazetteer:qualifier"),
    ]
    porphyria = mentions[1]
    assert porphyria.normalized == "porphyria"
    assert porphyria.score == 0.8
    # The model was loaded from the cached content path, and ONE call carried the whole vocabulary
    # — labels AND their descriptions, verbatim (the descriptions are what the prompt renders).
    assert _FakeAutoExtractor.loaded_from == [str(tmp_path)]
    _text, labels, threshold = _FakeAutoExtractor.model.calls[0]
    assert labels == MODEL_LABELS
    assert isinstance(labels, dict)
    assert all(labels.values())
    assert threshold == 0.42

    # A second extract reuses the cached model (from_pretrained called exactly once).
    backend.extract("asthma")
    assert len(_FakeAutoExtractor.loaded_from) == 1


def test_production_with_empty_gazetteer_is_model_only(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    _install_fake_gliner2(monkeypatch, tmp_path, [{"start": 0, "end": 9, "label": "biolink:PhenotypicFeature", "score": 0.6}])
    backend = DiseaseNER(offline=False, gazetteer={})
    mentions = backend.extract("porphyria")
    assert [(m.text, m.type, m.notes) for m in mentions] == [("porphyria", "PhenotypicFeature", "gliner")]


def test_trained_labels_preserve_disease_and_phenotype_types(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """The published checkpoint is trained on separate disease and phenotype labels."""
    _install_fake_gliner2(monkeypatch, tmp_path, [{"start": 0, "end": 9, "label": "biolink:PhenotypicFeature", "score": 0.8}])
    backend = DiseaseNER(offline=False, gazetteer={})
    mentions = backend.extract("porphyria")
    assert [(m.text, m.type, m.notes) for m in mentions] == [("porphyria", "PhenotypicFeature", "gliner")]


def test_extract_batch_uses_padded_inference_and_matches_single_texts(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A production worker sends multiple windows through one GLiNER batch call."""
    model = _FakeExtractorModel([{"start": 0, "end": 9, "label": "biolink:PhenotypicFeature", "score": 0.8}])
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)
    backend = DiseaseNER(offline=False, gazetteer={}, inference_batch_size=2)
    texts = ["porphyria", "porphyria"]

    batched = backend.extract_batch(texts)
    single = [backend.extract(text) for text in texts]

    assert batched == single
    assert [m.type for m in batched[0]] == ["PhenotypicFeature"]
    assert len(model.calls) == 4  # one inference item for each of two batched + two single calls


def test_extract_batch_handles_empty_text_and_model_filters(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    model = _FakeExtractorModel(
        [{"start": 0, "end": 5, "label": "CHEMICAL", "score": 0.8}, {"start": 0, "end": 5, "label": "biolink:PhenotypicFeature", "score": 0.8}]
    )
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)
    backend = DiseaseNER(offline=False, gazetteer={})
    assert backend.extract_batch([" "]) == [[]]
    assert [mention.text for row in backend.extract_batch(["women", ""]) for mention in row] == ["women"]


class _OverrunModel:
    """GLiNER2 stand-in reproducing the collator's synthetic-period offset overrun.

    Every span is reported as ending one char past the window that was actually sent, which is
    what the real collator does for a window whose last token is the ``"."`` it appended.
    """

    @staticmethod
    def batch_extract_entities(texts: list[str], _labels: Any, **_kwargs: Any) -> list[dict[str, Any]]:
        return [
            {"entities": {"biolink:Disease": [{"text": text[14:] + ".", "confidence": 0.99, "start": 14, "end": len(text) + 1}]}} for text in texts
        ]


def test_extract_batch_survives_a_span_that_overruns_the_window(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Regression guard for the run-8/run-9 shard killer: an over-running offset clamps instead of
    raising, and the surviving mention still satisfies ``text == source[start:end]``."""
    text = "indicated for chronic obstructive pulmonary disease"  # no terminal punctuation
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=_OverrunModel())
    backend = DiseaseNER(offline=False, gazetteer={}, device="cpu", workdir=tmp_path)
    mentions = backend.extract_batch([text])[0]
    assert [(mention.text, mention.type) for mention in mentions] == [("chronic obstructive pulmonary disease", "Disease")]
    assert text[mentions[0].start : mentions[0].end] == mentions[0].text


def test_extract_batch_isolates_an_unreadable_window_result(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A malformed model result costs ONE window its spans, not the shard its 40 minutes of GPU
    work: the texts keep their deterministic lexical mentions and the degradation is logged."""
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=_FakeExtractorModel([]))
    backend = DiseaseNER(offline=False, gazetteer={"asthma": "disease"}, device="cpu", workdir=tmp_path)

    def _boom(_result: Any, _window: str) -> Any:
        raise TypeError("entry has no start offset")

    monkeypatch.setattr(ner_module, "_spans_from_result", _boom)
    with _captured_logs() as lines:
        out = backend.extract_batch(["asthma in adults", "chronic hives"])
    assert [[mention.text for mention in row] for row in out] == [["asthma"], []]
    assert any("ner_window_spans: unreadable model result" in line for line in lines)
    assert any("ner_span_pass: degraded_windows = 2 of 2" in line for line in lines)


def test_extract_batch_isolates_a_text_whose_post_processing_fails(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A failure in the per-text merge degrades only that text to its lexical mentions."""
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=_FakeExtractorModel([]))
    backend = DiseaseNER(offline=False, gazetteer={"asthma": "disease"}, device="cpu", workdir=tmp_path)

    def _boom(*_args: Any, **_kwargs: Any) -> None:
        raise RuntimeError("merge blew up")

    monkeypatch.setattr(ner_module, "_merge_straddling_spans", _boom)
    with _captured_logs() as lines:
        out = backend.extract_batch(["asthma in adults"])
    assert [mention.text for mention in out[0]] == ["asthma"]
    assert any("ner_extract_text: post-processing failed" in line for line in lines)
    assert any("ner_extract_batch: degraded_texts = 1 of 1" in line for line in lines)


def test_model_labels_override_is_requested_verbatim(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """An explicitly overridden checkpoint declares its own label vocabulary via model_labels."""
    override = {"acme:Disease": "a named disorder", "acme:PhenotypicFeature": "a clinical finding"}
    _install_fake_gliner2(monkeypatch, tmp_path, [{"start": 0, "end": 9, "label": "biolink:PhenotypicFeature", "score": 0.8}])
    backend = DiseaseNER(offline=False, gazetteer={}, model_id="acme/other-ner", model_labels=override, cache_dir=tmp_path)
    mentions = backend.extract("porphyria")
    assert [(m.text, m.type) for m in mentions] == [("porphyria", "PhenotypicFeature")]
    _text, labels, _threshold = _FakeAutoExtractor.model.calls[0]
    assert labels == override  # the mapping is handed over verbatim, descriptions included
    assert backend._config()["model_labels"] == override  # and it round-trips through _config()


def test_empty_model_labels_is_rejected() -> None:
    with pytest.raises(ValueError, match="model_labels"):
        DiseaseNER(offline=False, model_labels={})


def test_load_model_returns_cached_model_without_reimport() -> None:
    sentinel = object()
    backend = DiseaseNER(offline=False)
    backend._model = sentinel  # pre-cache the model
    # With the model already cached, _load_model returns it without importing gliner2.
    assert backend._load_model() is sentinel
    assert "gliner2" not in sys.modules


def test_default_model_id_is_used(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    _FakeAutoExtractor.loaded_from = []
    _FakeAutoExtractor.model = _FakeExtractorModel([])
    module = types.ModuleType("gliner2")
    module.AutoExtractor = _FakeAutoExtractor  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "gliner2", module)
    seen: list[str] = []

    def _recording_ensure_model(model_id: str, **kwargs: Any) -> ModelRef:
        seen.append(model_id)
        return ModelRef(model_id=model_id, source="huggingface", path=tmp_path, b3="b3:x", manifest=tmp_path / "m.json")

    monkeypatch.setattr(ner_module, "ensure_model", _recording_ensure_model)
    DiseaseNER(offline=False).extract("asthma")
    assert seen == [DEFAULT_MODEL]


# --- population-descriptor filter: subject populations are not mentions ---------


def test_production_population_descriptor_spans_are_filtered(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """GLiNER loves to tag 'women of childbearing potential' as a phenotype; the blocklist drops it from
    the object channel. The closed sex lexicon still records ``women`` as a deterministic qualifier."""
    text = "Contraindicated in women of childbearing potential."
    start, end = text.index("women"), len(text) - 1  # 'women of childbearing potential'
    _install_fake_gliner2(monkeypatch, tmp_path, [{"start": start, "end": end, "label": "biolink:PhenotypicFeature", "score": 0.9}])
    backend = DiseaseNER(offline=False, gazetteer={})
    mentions = backend.extract(text)
    assert [mention for mention in mentions if mention.type in OBJECT_TYPES] == []
    assert [mention.text for mention in mentions if mention.type not in OBJECT_TYPES] == ["women"]


def test_population_filter_only_drops_exact_population_phrases(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    _install_fake_gliner2(monkeypatch, tmp_path, [{"start": 0, "end": 9, "label": "biolink:Disease", "score": 0.9}])
    backend = DiseaseNER(offline=False, gazetteer={})
    assert [m.text for m in backend.extract("porphyria cases")] == ["porphyria"]


# --- specificity merge: the most specific span wins on containment --------------


def _span(text: str, phrase: str, label: str, score: float) -> dict[str, Any]:
    """A fake gliner2 prediction for ``phrase`` at its (unique) offsets in ``text``."""
    start = text.index(phrase)
    return {"start": start, "end": start + len(phrase), "label": label, "score": score}


def test_model_span_containing_a_gazetteer_span_supersedes_it(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """'pulmonary hypertension' beats the gazetteer's bare 'hypertension' — the regression this
    merge exists for. The model supplies the boundary; the gazetteer keeps the type (GLiNER is
    the documented source of disease<->phenotype confusion, see ner/BENCHMARK.md)."""
    text = "Contraindicated in patients with severe pulmonary hypertension."
    _install_fake_gliner2(monkeypatch, tmp_path, [_span(text, "pulmonary hypertension", "biolink:PhenotypicFeature", 0.87)])

    mentions = DiseaseNER(offline=False, gazetteer={"hypertension": "Disease"}).extract(text)

    assert [(m.text, m.type, m.notes) for m in mentions] == [("pulmonary hypertension", "Disease", "gliner:extends")]
    assert mentions[0].score == pytest.approx(0.87)
    assert text[mentions[0].start : mentions[0].end] == "pulmonary hypertension"
    assert mentions[0].normalized == "pulmonary hypertension"


def test_unconfident_specific_span_abstains_instead_of_emitting_the_generic_one(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Below the acceptance floor the backend returns NOTHING. It must not fall back to
    'hypertension' — that would assert a broader contraindication than the label supports."""
    text = "Contraindicated in patients with severe pulmonary hypertension."
    _install_fake_gliner2(monkeypatch, tmp_path, [_span(text, "pulmonary hypertension", "biolink:Disease", 0.42)])

    backend = DiseaseNER(offline=False, gazetteer={"hypertension": "Disease"}, threshold=0.35, accept_threshold=0.5)
    assert backend.extract(text) == []


def test_plain_model_span_below_accept_floor_is_dropped(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A free-standing candidate generated above `threshold` but below `accept_threshold` is
    abstained on rather than asserted."""
    _install_fake_gliner2(monkeypatch, tmp_path, [{"start": 0, "end": 9, "label": "biolink:Disease", "score": 0.4}])
    backend = DiseaseNER(offline=False, gazetteer={}, threshold=0.35, accept_threshold=0.5)
    assert backend.extract("porphyria only") == []
    # ...and the same span clears a floor set below its score.
    _install_fake_gliner2(monkeypatch, tmp_path, [{"start": 0, "end": 9, "label": "biolink:Disease", "score": 0.4}])
    lenient = DiseaseNER(offline=False, gazetteer={}, threshold=0.35, accept_threshold=0.35)
    assert [m.text for m in lenient.extract("porphyria only")] == ["porphyria"]


@pytest.mark.parametrize(
    ("sentence", "phrase", "term"),
    [
        ("Contraindicated in patients with a recent myocardial infarction.", "a recent myocardial infarction", "myocardial infarction"),
        ("Contraindicated in patients with a history of peptic ulcer disease.", "a history of peptic ulcer disease", "peptic ulcer disease"),
        ("Do not use in patients with known hypersensitivity.", "known hypersensitivity", "hypersensitivity"),
    ],
)
def test_hedge_prefixes_are_trimmed_so_they_never_over_extend(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path, sentence: str, phrase: str, term: str
) -> None:
    """The over-extension that made overlap-extension too risky to ship (ner/BENCHMARK.md):
    temporal/evidential hedges are trimmed, so the model span collapses onto the gazetteer term
    instead of superseding it with a longer, meaningless boundary."""
    _install_fake_gliner2(monkeypatch, tmp_path, [_span(sentence, phrase, "biolink:Disease", 0.95)])
    mentions = DiseaseNER(offline=False, gazetteer={term: "Disease"}).extract(sentence)
    assert [(m.text, m.notes) for m in mentions] == [(term, "exact")]


def test_span_of_only_hedge_tokens_is_dropped(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    text = "Contraindicated in patients with asthma."
    _install_fake_gliner2(monkeypatch, tmp_path, [_span(text, "patients with", "biolink:Disease", 0.9)])
    assert DiseaseNER(offline=False, gazetteer={}).extract(text) == []


def test_population_descriptor_revealed_by_trimming_is_still_dropped(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """'in pregnant women' is not a population phrase until the leading 'in' comes off, so the
    filter has to run again on the trimmed surface. The deterministic sex qualifier is retained."""
    text = "Contraindicated in pregnant women."
    _install_fake_gliner2(monkeypatch, tmp_path, [_span(text, "in pregnant women", "biolink:PhenotypicFeature", 0.9)])
    mentions = DiseaseNER(offline=False, gazetteer={}).extract(text)
    assert [mention for mention in mentions if mention.type in OBJECT_TYPES] == []
    assert [(mention.text, mention.type) for mention in mentions if mention.type not in OBJECT_TYPES] == [("women", "BiologicalSex")]


def test_span_covering_several_gazetteer_terms_is_a_conjunction_not_a_qualifier(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A model span swallowing two gazetteer terms is 'asthma or hypertension', not one more
    specific disease — both gazetteer spans stand and the model span is discarded."""
    text = "Contraindicated in asthma or hypertension."
    _install_fake_gliner2(monkeypatch, tmp_path, [_span(text, "asthma or hypertension", "biolink:Disease", 0.99)])
    mentions = DiseaseNER(offline=False, gazetteer={"asthma": "Disease", "hypertension": "Disease"}).extract(text)
    assert [(m.text, m.notes) for m in mentions] == [("asthma", "exact"), ("hypertension", "exact")]


def test_partial_overlap_still_goes_to_the_gazetteer(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Neither span contains the other, so there is no specificity gain to bank — the
    high-precision gazetteer span wins, exactly as before this merge existed."""
    text = "congestive heart failure risk"
    _install_fake_gliner2(monkeypatch, tmp_path, [_span(text, "failure risk", "biolink:PhenotypicFeature", 0.99)])
    mentions = DiseaseNER(offline=False, gazetteer={"heart failure": "Disease"}).extract(text)
    assert [(m.text, m.type, m.notes) for m in mentions] == [("heart failure", "Disease", "exact")]


def test_overlapping_model_spans_resolve_longest_first(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Model-vs-model: the longer span wins even when the shorter one scores higher."""
    text = "severe pulmonary hypertension noted"
    predictions = [_span(text, "hypertension", "biolink:Disease", 0.95), _span(text, "pulmonary hypertension", "biolink:Disease", 0.6)]
    _install_fake_gliner2(monkeypatch, tmp_path, predictions)
    mentions = DiseaseNER(offline=False, gazetteer={}).extract(text)
    assert [(m.text, m.notes) for m in mentions] == [("pulmonary hypertension", "gliner")]


def test_equal_length_overlapping_model_spans_break_ties_deterministically(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    text = "alpha beta gamma"
    _install_fake_gliner2(
        monkeypatch, tmp_path, [_span(text, "alpha beta", "biolink:Disease", 0.6), _span(text, "beta gamma", "biolink:Disease", 0.9)]
    )
    assert [m.text for m in DiseaseNER(offline=False, gazetteer={}).extract(text)] == ["beta gamma"]  # equal length -> higher score

    # A full tie falls back to the leftmost span, so repeated runs agree.
    _install_fake_gliner2(
        monkeypatch, tmp_path, [_span(text, "alpha beta", "biolink:Disease", 0.9), _span(text, "beta gamma", "biolink:Disease", 0.9)]
    )
    assert [m.text for m in DiseaseNER(offline=False, gazetteer={}).extract(text)] == ["alpha beta"]


def test_trim_hedges_returns_none_for_a_tokenless_span() -> None:
    """A span that is pure whitespace has no GLiNER tokens to walk — dropped, not crashed."""
    assert _trim_hedges("a   b", 1, 4) is None
    assert _trim_hedges("recent asthma", 0, 13) == (7, 13)
    assert _trim_hedges("asthma flare", 0, 12) == (0, 12)  # no leading hedge -> untouched


def test_offline_mode_keeps_its_gazetteer_granularity(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Deliberate: offline mode has no model, so it still returns the generic gazetteer term.
    Specificity is a production-mode capability; offline stays the deterministic baseline."""
    text = "Contraindicated in patients with severe pulmonary hypertension."
    mentions = DiseaseNER(offline=True, gazetteer={"hypertension": "Disease"}).extract(text)
    assert [(m.text, m.notes) for m in mentions] == [("hypertension", "exact")]


# --- cross-window rejoin: hard splits can cut a multiword mention in two --------


_SPLIT_FILLER = " ".join(f"word{i}" for i in range(39))  # puts 'myasthenia' flush at a hard-split boundary
_SPLIT_PROBE = f"{_SPLIT_FILLER} myasthenia gravis must be excluded"


class _WindowRoutedFakeModel:
    """Fake gliner2 model whose predictions depend on which window it is given (window-relative
    offsets, like the real model). The first route whose key occurs in the window wins."""

    def __init__(self, routes: dict[str, list[dict[str, Any]]]) -> None:
        self.routes = routes
        self.calls: list[str] = []

    def extract_entities(self, text: str, entity_types: Mapping[str, str], threshold: float = 0.5, **_kwargs: Any) -> dict[str, Any]:
        self.calls.append(text)
        for key, predictions in self.routes.items():
            if key in text:
                return _gliner2_result(predictions, text)
        return {"entities": {}}


def _split_probe_span(window: str, phrase: str) -> tuple[int, int]:
    start = window.index(phrase)
    return start, start + len(phrase)


def test_production_straddling_spans_rejoin_across_hard_split(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """'myasthenia | gravis' cut by a hard split comes back as ONE 'myasthenia gravis' span."""
    windows = _windows(_SPLIT_PROBE, 20)
    assert len(windows) == 3
    assert windows[2][0] > windows[1][0] + len(windows[1][1])  # hard-split gap
    left_start, left_end = _split_probe_span(windows[1][1], "myasthenia")
    assert left_end == len(windows[1][1])  # flush at the window end
    right_start, right_end = _split_probe_span(windows[2][1], "gravis")
    assert right_start == 0  # flush at the next window start

    model = _WindowRoutedFakeModel(
        {
            "myasthenia": [{"start": left_start, "end": left_end, "label": "biolink:Disease", "score": 0.9}],
            "gravis": [{"start": right_start, "end": right_end, "label": "biolink:PhenotypicFeature", "score": 0.6}],
        }
    )
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)

    mentions = DiseaseNER(offline=False, gazetteer={}, chunk_words=20).extract(_SPLIT_PROBE)
    assert [(m.text, m.type) for m in mentions] == [("myasthenia gravis", "Disease")]  # higher-scoring side's type
    assert mentions[0].score == pytest.approx(0.9)
    assert _SPLIT_PROBE[mentions[0].start : mentions[0].end] == "myasthenia gravis"


def test_production_straddling_rejoin_takes_higher_scoring_type(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    windows = _windows(_SPLIT_PROBE, 20)
    left_start, left_end = _split_probe_span(windows[1][1], "myasthenia")
    right_start, right_end = _split_probe_span(windows[2][1], "gravis")
    model = _WindowRoutedFakeModel(
        {
            "myasthenia": [{"start": left_start, "end": left_end, "label": "biolink:Disease", "score": 0.6}],
            "gravis": [{"start": right_start, "end": right_end, "label": "biolink:PhenotypicFeature", "score": 0.95}],
        }
    )
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)
    mentions = DiseaseNER(offline=False, gazetteer={}, chunk_words=20).extract(_SPLIT_PROBE)
    assert [(m.text, m.type) for m in mentions] == [("myasthenia gravis", "PhenotypicFeature")]
    assert mentions[0].score == pytest.approx(0.95)


def test_production_straddling_rejoin_tie_keeps_left_type(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    windows = _windows(_SPLIT_PROBE, 20)
    left_start, left_end = _split_probe_span(windows[1][1], "myasthenia")
    right_start, right_end = _split_probe_span(windows[2][1], "gravis")
    model = _WindowRoutedFakeModel(
        {
            "myasthenia": [{"start": left_start, "end": left_end, "label": "biolink:Disease", "score": 0.8}],
            "gravis": [{"start": right_start, "end": right_end, "label": "biolink:PhenotypicFeature", "score": 0.8}],
        }
    )
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)
    mentions = DiseaseNER(offline=False, gazetteer={}, chunk_words=20).extract(_SPLIT_PROBE)
    assert [(m.text, m.type) for m in mentions] == [("myasthenia gravis", "Disease")]


def test_production_single_edge_span_is_kept_without_merge(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Only one side of a hard-split boundary predicted -> no merge, the span survives as-is."""
    windows = _windows(_SPLIT_PROBE, 20)
    left_start, left_end = _split_probe_span(windows[1][1], "myasthenia")
    right_start, right_end = _split_probe_span(windows[2][1], "gravis")

    left_only = _WindowRoutedFakeModel({"myasthenia": [{"start": left_start, "end": left_end, "label": "biolink:Disease", "score": 0.9}]})
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=left_only)
    mentions = DiseaseNER(offline=False, gazetteer={}, chunk_words=20).extract(_SPLIT_PROBE)
    assert [(m.text, m.type) for m in mentions] == [("myasthenia", "Disease")]

    right_only = _WindowRoutedFakeModel({"gravis": [{"start": right_start, "end": right_end, "label": "biolink:PhenotypicFeature", "score": 0.6}]})
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=right_only)
    mentions = DiseaseNER(offline=False, gazetteer={}, chunk_words=20).extract(_SPLIT_PROBE)
    assert [(m.text, m.type) for m in mentions] == [("gravis", "PhenotypicFeature")]


def test_production_no_merge_across_contiguous_sentence_boundary(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Sentence-piece windows tile gap-free, so flush spans on both sides stay separate mentions."""
    text = "Asthma attack. Porphyria noted."
    windows = _windows(text, 3)
    assert len(windows) == 2
    assert windows[1][0] == windows[0][0] + len(windows[0][1])  # contiguous boundary
    model = _WindowRoutedFakeModel(
        {
            "Asthma": [{"start": 0, "end": len(windows[0][1]), "label": "biolink:Disease", "score": 0.9}],
            "Porphyria": [{"start": 0, "end": 9, "label": "biolink:Disease", "score": 0.9}],
        }
    )
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)
    mentions = DiseaseNER(offline=False, gazetteer={}, chunk_words=3).extract(text)
    # The trailing space of the first span is stripped by gliner2's surface reporting and the
    # offsets strip-aligned to match, so the mention carries the trimmed surface.
    assert [(m.text, m.type) for m in mentions] == [("Asthma attack.", "Disease"), ("Porphyria", "Disease")]


# --- windowing: GLiNER truncates long inputs, so long texts are predicted per window ---


class _WindowAwareFakeModel:
    """Fake gliner2 model that predicts every occurrence of ``needle`` inside the window it is
    given (offsets window-relative, exactly like the real model)."""

    def __init__(self, needle: str, label: str = "biolink:Disease", score: float = 0.9) -> None:
        self.needle = needle
        self.label = label
        self.score = score
        self.calls: list[str] = []

    def extract_entities(self, text: str, entity_types: Mapping[str, str], threshold: float = 0.5, **_kwargs: Any) -> dict[str, Any]:
        self.calls.append(text)
        entities: list[dict[str, Any]] = []
        index = 0
        while (found := text.find(self.needle, index)) != -1:
            entities.append({"text": self.needle, "confidence": self.score, "start": found, "end": found + len(self.needle)})
            index = found + len(self.needle)
        return {"entities": {self.label: entities}}


_LONG_FILLER = "The label states the drug is contraindicated under the circumstances described here. " * 10


def test_production_long_text_is_windowed_and_offsets_remap(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    text = _LONG_FILLER + "Patients with porphyria must not receive it."
    model = _WindowAwareFakeModel("porphyria")
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)

    backend = DiseaseNER(offline=False, gazetteer={}, chunk_words=25)
    mentions = backend.extract(text)

    # Windowed, not one truncated call; windows tile the section exactly and each fits the budget.
    assert len(model.calls) > 1
    assert "".join(model.calls) == text
    assert all(len(_GLINER_TOKEN.findall(call)) <= 25 for call in model.calls)

    # The late mention (past the first window's 384-token-style truncation point) is found and
    # its offsets remap into full-text coordinates.
    assert [(m.text, m.type, m.notes) for m in mentions] == [("porphyria", "Disease", "gliner")]
    mention = mentions[0]
    assert text[mention.start : mention.end] == "porphyria"
    assert mention.start > len(model.calls[0])
    assert mention.normalized == "porphyria"
    assert mention.score == 0.9


def test_production_short_text_is_a_single_full_text_window(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    model = _WindowAwareFakeModel("porphyria")
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)
    text = "porphyria only"
    DiseaseNER(offline=False, gazetteer={}).extract(text)
    assert model.calls == [text]  # nothing ≤ budget changes vs the pre-windowing behavior


def test_production_gazetteer_wins_in_later_windows(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    text = _LONG_FILLER + "Patients with asthma must not receive it."
    model = _WindowAwareFakeModel("asthma")
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)

    backend = DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, chunk_words=25)
    mentions = backend.extract(text)

    assert len(model.calls) > 1
    # Gazetteer span wins on overlap even when the GLiNER span comes from a later window.
    assert [(m.text, m.type, m.notes) for m in mentions] == [("asthma", "Disease", "exact")]


def test_production_oversize_single_sentence_is_hard_split(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    filler = " ".join(f"word{i}" for i in range(60))  # one sentence, no terminal punctuation
    text = filler + " porphyria"
    model = _WindowAwareFakeModel("porphyria")
    _install_fake_gliner2(monkeypatch, tmp_path, [], model=model)

    backend = DiseaseNER(offline=False, gazetteer={}, chunk_words=20)
    mentions = backend.extract(text)

    assert len(model.calls) > 1
    assert model.calls == [window for _, window in _windows(text, 20)]
    assert all(len(_GLINER_TOKEN.findall(call)) <= 20 for call in model.calls)
    assert [(m.text, m.notes) for m in mentions] == [("porphyria", "gliner")]
    assert text[mentions[0].start : mentions[0].end] == "porphyria"


# --- _windows: exact-substring tiling, budgets, fallbacks -------------------------------


def test_windows_single_window_when_text_fits() -> None:
    text = "Contraindicated in asthma and headache."
    assert _windows(text, _DEFAULT_WORD_BUDGET) == [(0, text)]


def test_windows_blank_text_yields_nothing() -> None:
    assert _windows("", 384) == []
    assert _windows("   \t\n ", 384) == []


def test_windows_tile_the_text_exactly_and_fit_the_budget() -> None:
    text = "Asthma attack. " * 40 + "Porphyria noted. " * 40
    windows = _windows(text, 25)
    assert len(windows) > 1
    assert "".join(window for _, window in windows) == text
    offset = 0
    for start, window in windows:
        assert start == offset
        assert text[start : start + len(window)] == window
        assert len(_GLINER_TOKEN.findall(window)) <= 25
        offset += len(window)


def test_windows_hard_split_oversize_sentence() -> None:
    text = " ".join(f"word{i}" for i in range(100))  # one sentence, no terminal punctuation
    windows = _windows(text, 30)
    assert len(windows) == 4  # 100 tokens -> 30 + 30 + 30 + 10
    for start, window in windows:
        assert text[start : start + len(window)] == window
        assert len(_GLINER_TOKEN.findall(window)) <= 30
    assert all(f"word{i}" in "".join(window for _, window in windows) for i in range(100))


def test_windows_counts_gliner_tokens_not_whitespace_words() -> None:
    # 3 whitespace words but 6 GLiNER tokens (each punctuation glyph is its own token), so a
    # budget of 4 must still split — GLiNER's own truncation counts these tokens.
    assert len(_windows("x, y; z.", 4)) == 2


def test_windows_falls_back_to_single_piece_for_untileable_text() -> None:
    # Leading punctuation, dangling terminals and gaps break the sentence tiling; the whole text
    # becomes one piece and still yields one (windowed) exact substring when it fits the budget.
    for text in (".", "!abc.", "a. .", "a. .b"):
        assert _windows(text, _DEFAULT_WORD_BUDGET) == [(0, text)]


# --- _token_budget: override > model config > default ------------------------------------


def test_token_budget_override_wins_and_clamps() -> None:
    assert _token_budget(None, 25) == 25
    assert _token_budget(None, 1) == 1
    assert _token_budget(None, 0) == 1
    assert _token_budget(None, -5) == 1


def test_token_budget_reads_model_config_max_len() -> None:
    class _Model:
        class config:
            max_len = 512

    assert _token_budget(_Model(), None) == 512


def test_token_budget_falls_back_to_default() -> None:
    assert _token_budget(object(), None) == _DEFAULT_WORD_BUDGET  # no .config attribute

    class _NoMaxLen:
        config = None

    assert _token_budget(_NoMaxLen(), None) == _DEFAULT_WORD_BUDGET

    class _NonInt:
        class config:
            max_len = "nope"

    assert _token_budget(_NonInt(), None) == _DEFAULT_WORD_BUDGET

    class _TooSmall:
        class config:
            max_len = 0

    assert _token_budget(_TooSmall(), None) == _DEFAULT_WORD_BUDGET


# --- device parameter: pin GLiNER to a specific GPU for multi-GPU dispatch ---------


def test_device_param_pins_model_to_specified_gpu(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """An explicit ``device`` kwarg flows through to ``map_location`` at model load time."""
    _install_fake_gliner2(monkeypatch, tmp_path, [])
    backend = DiseaseNER(offline=False, device="cuda:2", cache_dir=tmp_path)
    backend.extract("some text")
    assert _FakeAutoExtractor.loaded_map_location == ["cuda:2"]


def test_device_none_falls_back_to_model_device(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """When ``device`` is None, ``_load_model`` uses ``_model_device()`` (auto-detect)."""
    _install_fake_gliner2(monkeypatch, tmp_path, [])
    backend = DiseaseNER(offline=False, cache_dir=tmp_path)  # device=None
    backend.extract("some text")
    # _model_device() returns "cpu" in CI (no CUDA) or "cuda" when available.
    assert _FakeAutoExtractor.loaded_map_location[0] in ("cpu", "cuda")


# --- _config: serializable construction kwargs for multi-process workers ------------


def test_config_returns_serializable_construction_kwargs(tmp_path: Path) -> None:
    gaz = Gazetteer({"asthma": "Disease"})
    backend = DiseaseNER(
        offline=False,
        gazetteer=gaz,
        model_id="acme/ner",
        threshold=0.42,
        accept_threshold=0.66,
        chunk_words=128,
        cache_dir=tmp_path,
        workdir=tmp_path / "work",
        device="cuda:1",
    )
    config = backend._config()
    assert config["offline"] is False
    assert config["model_id"] == "acme/ner"
    assert config["threshold"] == 0.42
    # Must round-trip: the multi-GPU workers rebuild from this dict, and a missing key would
    # silently run all four P100s at the default floor while the parent ran tuned.
    assert config["accept_threshold"] == 0.66
    assert config["strict_extension_threshold"] is None
    assert config["chunk_words"] == 128
    assert config["cache_dir"] == tmp_path
    assert config["workdir"] == tmp_path / "work"
    assert config["gazetteer"] is gaz
    # device is deliberately excluded — the caller sets it per-worker.
    assert "device" not in config


def test_strict_extension_profile_keeps_exact_anchor_when_model_extension_is_weak(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    text = "Contraindicated in patients with hypersensitivity to ibuprofen."
    _install_fake_gliner2(monkeypatch, tmp_path, [_span(text, "hypersensitivity to ibuprofen.", "biolink:PhenotypicFeature", 0.89)])
    backend = DiseaseNER.for_contraindications(offline=False, gazetteer={"hypersensitivity": "PhenotypicFeature"})
    mentions = backend.extract(text)
    assert [(mention.text, mention.notes) for mention in mentions] == [("hypersensitivity", "exact")]


def test_strict_extension_profile_accepts_confident_specific_boundary(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    text = "Contraindicated in patients with pulmonary hypertension."
    _install_fake_gliner2(monkeypatch, tmp_path, [_span(text, "pulmonary hypertension", "biolink:Disease", 0.99)])
    backend = DiseaseNER.for_contraindications(offline=False, gazetteer={"hypertension": "Disease"})
    mentions = backend.extract(text)
    assert [(mention.text, mention.notes) for mention in mentions] == [("pulmonary hypertension", "gliner:extends")]


def test_config_can_reconstruct_equivalent_backend(tmp_path: Path) -> None:
    """A DiseaseNER built from ``_config()`` + a ``device`` produces the same mentions."""
    original = DiseaseNER(offline=True, gazetteer={"asthma": "Disease"}, device="cuda:3")
    reconstructed = DiseaseNER(device="cuda:0", **original._config())
    text = "patient has asthma"
    assert [m.text for m in reconstructed.extract(text)] == [m.text for m in original.extract(text)]
    assert reconstructed._offline == original._offline


# --- Tier B raw-span path (extract_spans_batch / merge_spans) --------------------


def test_span_path_is_byte_identical_to_extract_batch(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """extract_spans_batch + merge_spans must produce EXACTLY what extract_batch produces.

    The two-tier cache rides on this: cached raw spans re-merged parent-side replace a GPU
    re-mine, so any drift between the split path and the fused path would silently change
    production mentions depending on cache state. The equality is the invariant, asserted per
    text on real (fake-model) output including gazetteer contests and qualifier routing.
    """
    predictions = [
        {"start": 20, "end": 30, "label": "biolink:Disease", "score": 0.97},  # OOV: asthma-adjacent span
        {"start": 0, "end": 7, "label": "biolink:Disease", "score": 0.9},  # overlaps gazetteer below
    ]
    _install_fake_gliner2(monkeypatch, tmp_path, predictions)
    texts = ["Contraindicated in patients with pulmonary hypertension.", "Avoid use in patients with asthma or recent myocardial infarction."]
    backend = DiseaseNER(offline=False, gazetteer={"asthma": "Disease", "hypertension": "Disease"}, device="cpu", workdir=tmp_path)

    fused = backend.extract_batch(texts)
    raw = backend.extract_spans_batch(texts)
    split = [backend.merge_spans(text, spans) for text, spans in zip(texts, raw, strict=True)]
    assert split == fused


def test_raw_text_spans_cache_round_trip_and_window_mismatch(tmp_path: Path) -> None:
    """to_cache/from_cache is lossless for matching tilings and a MISS for mismatched ones.

    The stored payload drops window TEXTS (recomputable from text + budget) and keeps starts;
    from_cache recomputes the tiling and refuses entries whose starts disagree - that refusal is
    what makes a budget change a safe miss instead of a corrupt merge.
    """
    from dakp_pipeline.ner.ner import RawTextSpans, _ModelSpan, spans_from_cache

    text = "Contraindicated in patients with asthma."
    windows = [(0, text)]
    spans = RawTextSpans(
        windows=windows,
        objects=[[_ModelSpan(start=29, end=35, type="Disease", score=0.9)]],
        qualifiers=[_ModelSpan(start=0, end=14, type="temporal_context_qualifier", score=0.4)],
    )
    payload = spans.to_cache()
    assert "starts" in payload
    assert payload["starts"] == [0]

    model_dir = tmp_path  # no config.json -> the 384 fallback, same as the runtime budget here
    rebuilt = spans_from_cache(text, model_dir, None, payload)
    assert rebuilt is not None
    assert rebuilt.windows == windows
    assert rebuilt.objects == spans.objects
    assert rebuilt.qualifiers == spans.qualifiers

    tampered = dict(payload)
    tampered["starts"] = [5]  # a different budget's tiling
    assert spans_from_cache(text, model_dir, None, tampered) is None
    corrupt = {"starts": [0]}  # missing span fields
    assert spans_from_cache(text, model_dir, None, corrupt) is None


def test_span_material_excludes_merge_side_config(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Tier B keys must move with MODEL-side config only, never merge-side config.

    Gazetteer growth and accept-threshold sweeps are the cheapest iteration loops in this
    pipeline; if either changed the span fingerprint, every sweep would re-mine on GPU and the
    two-tier design would be dead on arrival. The generation threshold and the label vocabulary
    DO change model output, so they must be IN.
    """
    _install_fake_gliner2(monkeypatch, tmp_path, [])
    base = DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, device="cpu", workdir=tmp_path)

    gazetteer_growth = DiseaseNER(offline=False, gazetteer={"asthma": "Disease", "cirrhosis": "Disease"}, device="cpu", workdir=tmp_path)
    accept_sweep = DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, accept_threshold=0.9, device="cpu", workdir=tmp_path)
    batch_bump = DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, inference_batch_size=64, device="cpu", workdir=tmp_path)
    assert gazetteer_growth.span_material() == base.span_material()
    assert accept_sweep.span_material() == base.span_material()
    assert batch_bump.span_material() == base.span_material()

    relabeled = DiseaseNER(
        offline=False, gazetteer={"asthma": "Disease"}, model_labels={"biolink:Disease": "a disease"}, device="cpu", workdir=tmp_path
    )
    regen = DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, threshold=0.5, device="cpu", workdir=tmp_path)
    rebudget = DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, chunk_words=512, device="cpu", workdir=tmp_path)
    assert relabeled.span_material() != base.span_material()
    assert regen.span_material() != base.span_material()
    assert rebudget.span_material() != base.span_material()


# --- length-bucketed batching (zero accuracy change) -------------------------------


class _BatchRecordingModel:
    """Fake gliner2 model that records each batch's texts and tags results per text."""

    def __init__(self) -> None:
        self.batches: list[list[str]] = []

    def batch_extract_entities(self, texts: list[str], entity_types: Any, batch_size: int = 8, **_kwargs: Any) -> list[dict[str, Any]]:
        for start in range(0, len(texts), batch_size):
            self.batches.append(texts[start : start + batch_size])
        return [{"entities": {text: []}, "text": text} for text in texts]


def test_infer_chunk_sorts_by_length_and_restores_order(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Batches are near-uniform in length; outputs land back in submission order.

    Sorting is a pure throughput change: every window's result depends only on its own text, so
    the reordered submission must not move any result - asserted here element-for-element against
    an unsorted reference run over the same mixed-length shard.
    """
    lengths = [4000, 30, 3800, 45, 3900, 12, 2050, 60, 1990, 22]
    texts = [("word " * length).strip() for length in lengths]
    recording = _BatchRecordingModel()
    backend = DiseaseNER(offline=False, gazetteer={}, inference_batch_size=2, device="cpu", workdir=tmp_path)

    reference = _BatchRecordingModel()
    # Reference: batching WITHOUT sorting (patch the sort out by calling _raw_batch_extract directly).
    unsorted_results = backend._raw_batch_extract(reference, list(texts), 2)

    results = backend._infer_chunk(recording, list(texts), 2)
    assert results == unsorted_results  # byte-identity: same window, same result, any order

    # Each batch pads to its longest member; sorted batches pad far less in total than the
    # unsorted ones (which pair 4000-word windows with 12-word ones).
    def total_pad(batches: list[list[str]]) -> int:
        return sum(max(len(text) for text in batch) * len(batch) - sum(len(text) for text in batch) for batch in batches)

    assert total_pad(recording.batches) < total_pad(reference.batches)
    # The first batch holds the SHORTEST windows, the last the longest.
    assert len(recording.batches[0][0]) < len(recording.batches[-1][0])


def test_infer_chunk_bisects_the_sorted_list_and_keeps_order(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Fallback paths (bisect) operate on the sorted list; results still restore order."""
    texts = ["x" * n for n in (500, 10, 300, 20, 400, 5)]
    flaky = _BatchRecordingModel()
    calls = {"n": 0}
    original = flaky.batch_extract_entities

    def flaky_extract(texts: list[str], entity_types: Any, batch_size: int = 8, **kwargs: Any) -> list[dict[str, Any]]:
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("one pathological window")
        return original(texts, entity_types, batch_size=batch_size, **kwargs)

    flaky.batch_extract_entities = flaky_extract  # type: ignore[method-assign]
    backend = DiseaseNER(offline=False, gazetteer={}, device="cpu", workdir=tmp_path)
    results = backend._infer_chunk(flaky, list(texts), 2)
    assert len(results) == len(texts)
    assert all(result["text"] == text for result, text in zip(results, texts, strict=True))


# --- stall recovery: OOM-halving cap, stall watchdog, chunk heartbeat --------------------


class _OomModel:
    """Fake model whose batched call always raises a device-OOM-shaped error."""

    def __init__(self) -> None:
        self.attempts: list[int] = []

    def batch_extract_entities(self, texts: list[str], entity_types: Any, batch_size: int = 8, **_kwargs: Any) -> list[dict[str, Any]]:
        self.attempts.append(batch_size)
        raise RuntimeError("CUDA out of memory. Tried to allocate 2.26 GiB")


def test_infer_chunk_caps_oom_halving_then_bisects(tmp_path: Path) -> None:
    """OOM halving is capped per piece; the cap spills into bisection, never an unbounded spiral.

    Each halving re-runs every window in the piece, so an unbounded 16→8→4→2→1 spiral re-pays
    the full piece cost per attempt (recorded: 4 halvings then 2048 single-window retries, all
    lost). Two attempts per piece, then the piece is bisected: a half that infers cleanly
    exonerates the batch size, and a lone OOM window is dropped — the shard survives.
    """
    model = _OomModel()
    backend = DiseaseNER(offline=False, gazetteer={}, device="cpu", workdir=tmp_path)
    texts = ["patient has asthma"] * 8
    results = backend._infer_chunk(model, texts, 8)
    assert len(results) == 8  # the chunk still returns, one canonical-empty entry per window
    # Every piece tried at most _MAX_OOM_HALVINGS halvings: batch sizes only ever descend
    # 8 -> 4 -> 2 (then the piece splits), never 8 -> 4 -> 2 -> 1 inside one piece.
    first_piece = model.attempts[:3]
    assert first_piece == [8, 4, 2]
    assert 1 not in first_piece


def test_infer_windows_emits_chunk_heartbeats(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """Each inference chunk emits a progress heartbeat with cumulative window counts."""
    from dakp_pipeline.ner import ner as ner_module

    heartbeats: list[dict[str, Any]] = []
    real_stats = ner_module.stats
    monkeypatch.setattr(
        ner_module,
        "stats",
        lambda log, event, **fields: (
            heartbeats.append({"event": event, **fields}) if event == "ner_infer_progress" else real_stats(log, event, **fields)
        ),
    )
    model = _BatchRecordingModel()
    backend = DiseaseNER(offline=False, gazetteer={}, device="cpu", workdir=tmp_path)
    texts = [f"window text {i}" for i in range(5)]
    backend._infer_windows(model, texts)
    assert len(heartbeats) == 1  # one chunk (5 < _INFERENCE_CHUNK_WINDOWS)
    assert heartbeats[0]["windows_done"] == 5
    assert heartbeats[0]["windows_total"] == 5


def test_stall_watchdog_is_inert_without_cuda(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """CPU inference (and the test suite) never arms the watchdog: direct call, same result."""
    model = _BatchRecordingModel()
    backend = DiseaseNER(offline=False, gazetteer={}, device="cpu", workdir=tmp_path)
    texts = ["a", "bb", "ccc"]
    results = backend._run_with_stall_watchdog(model, texts, 2)
    assert [result["text"] for result in results] == texts


# --- compute dtype (fp32 default, fp16 opt-in) --------------------------------------


def test_compute_dtype_is_model_side_key_material(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A dtype change moves the Tier B fingerprint (fp16 output bits differ from fp32)."""
    _install_fake_gliner2(monkeypatch, tmp_path, [])
    default = DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, device="cpu", workdir=tmp_path)
    assert default.span_material()["compute_dtype"] == "fp32"  # production default: full precision
    fp32 = DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, device="cpu", workdir=tmp_path, compute_dtype="fp32")
    fp16 = DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, device="cpu", workdir=tmp_path, compute_dtype="fp16")
    assert fp32.span_material() != fp16.span_material()
    assert fp32.span_material()["compute_dtype"] == "fp32"
    # The default IS fp32, so a default backend keeps matching an fp32-mined store (warm cache).
    assert default.span_material() == fp32.span_material()
    # Worker reconstruction carries the dtype.
    rebuilt = DiseaseNER(device="cpu", **dict(fp16._config()))
    assert rebuilt._config()["compute_dtype"] == "fp16"


def test_compute_dtype_rejects_unknown_values(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="compute_dtype"):
        DiseaseNER(offline=False, gazetteer={"asthma": "Disease"}, device="cpu", workdir=tmp_path, compute_dtype="bf16")


def test_fp16_autocast_arms_only_on_cuda(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """fp16 + CPU runs the plain call; the autocast branch is reachable only with cuda."""
    _install_fake_gliner2(monkeypatch, tmp_path, [])
    backend = DiseaseNER(offline=False, gazetteer={}, device="cpu", workdir=tmp_path, compute_dtype="fp16")
    model = _BatchRecordingModel()
    results = backend._raw_batch_extract(model, ["a", "bb"], 2)
    assert [r["text"] for r in results] == ["a", "bb"]  # inert on CPU, no autocast error
    # Sanity: the default backend (fp32) takes the same non-autocast branch on CPU.
    default_backend = DiseaseNER(offline=False, gazetteer={}, device="cpu", workdir=tmp_path)
    assert default_backend._raw_batch_extract(model, ["a"], 1)[0]["text"] == "a"


def test_explicit_fp16_autocast_arms_on_cuda_and_the_fp32_default_does_not(fake_torch: Any, monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """A CUDA-pinned fp16 backend wraps the forward in ``torch.autocast('cuda', float16)``; the
    fp32 default does not, which is what keeps the fp32-mined cache warm.

    ``torch.autocast`` itself is replaced with a recording fake so the assertion is exact and
    GPU-independent: real cuda autocast silently disables itself on a host with no device
    (observed: this test green locally on a GPU host, red on the GPU-less CI runner), and what
    DAKP owns is the arming decision in ``_raw_batch_extract``, not torch's autocast internals.
    The CPU test above already proves the non-cuda path never enters the context.
    """
    _install_fake_gliner2(monkeypatch, tmp_path, [])
    entered: list[tuple[str, Any]] = []

    @contextmanager
    def _recording_autocast(device_type: str, **kwargs: Any) -> Iterator[None]:
        entered.append((device_type, kwargs.get("dtype")))
        yield

    monkeypatch.setattr(fake_torch, "autocast", _recording_autocast)
    backend = DiseaseNER(offline=False, gazetteer={}, device="cuda", workdir=tmp_path, compute_dtype="fp16")
    backend._raw_batch_extract(_BatchRecordingModel(), ["a"], 1)
    assert entered == [("cuda", fake_torch.float16)]  # explicit fp16 arms autocast on a cuda device
    # The fp32 default must NOT autocast: its output bits are what the warm store was mined with.
    entered.clear()
    default_backend = DiseaseNER(offline=False, gazetteer={}, device="cuda", workdir=tmp_path)
    default_backend._raw_batch_extract(_BatchRecordingModel(), ["a"], 1)
    assert entered == []


# --- qualifier surface blocklist: measured junk the prompt alone did not prevent ------------


def test_qualifier_surface_blocklist_drops_measured_junk_spans(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """The wenceslaus NER-export scan (187,314 shipped training examples / 4.25M mentions)
    measured dose-amount nouns tagged as frequency_qualifier, age/species words tagged as
    BiologicalSex (biolink defines it as the organismal sex quality itself, PATO:0000047, not a
    life-stage or species attribute) and the condition noun 'pregnancy' tagged as
    temporal_context_qualifier. Each blocked surface is abstained on, never emitted."""
    text = "Do not exceed the recommended dosage. Adults and humans: history of pregnancy."
    predictions = [
        {"start": text.index("dosage"), "end": text.index("dosage") + 6, "label": "frequency_qualifier", "score": 0.9},
        {"start": text.index("Adults"), "end": text.index("Adults") + 6, "label": "biolink:BiologicalSex", "score": 0.9},
        {"start": text.index("humans"), "end": text.index("humans") + 6, "label": "biolink:BiologicalSex", "score": 0.8},
        {"start": text.index("pregnancy"), "end": text.index("pregnancy") + 9, "label": "temporal_context_qualifier", "score": 0.7},
    ]
    _install_fake_gliner2(monkeypatch, tmp_path, predictions)
    mentions = DiseaseNER(offline=False, gazetteer={}).extract(text)
    assert mentions == []


def test_qualifier_surface_blocklist_is_exact_surface_per_type(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """The blocklist gates exact normalized surfaces on their own qualifier type only: the same
    word on the object channel and legitimate qualifier wording survive untouched."""
    text = "Contraindicated during pregnancy and lactation. Take once daily with food in women."
    predictions = [
        # 'pregnancy' blocked ONLY as temporal_context_qualifier; as the object-channel finding it stands.
        {"start": text.index("pregnancy"), "end": text.index("pregnancy") + 9, "label": "biolink:PhenotypicFeature", "score": 0.9},
        {"start": text.index("once daily"), "end": text.index("once daily") + 10, "label": "frequency_qualifier", "score": 0.8},
        {"start": text.index("women"), "end": text.index("women") + 5, "label": "biolink:BiologicalSex", "score": 0.9},
    ]
    _install_fake_gliner2(monkeypatch, tmp_path, predictions)
    mentions = DiseaseNER(offline=False, gazetteer={}).extract(text)
    assert [(m.text, m.type) for m in mentions] == [
        ("pregnancy", "PhenotypicFeature"),
        ("once daily", "frequency_qualifier"),
        ("women", "BiologicalSex"),
    ]
