"""DAG wiring tests for the Airflow-native ``dakp_pipeline`` DAG (Airflow 3 is a hard dependency).

The DAG always imports and constructs (no optional-extra guard). These tests assert the module
constants, the 17-task graph, the visual TaskGroups (with unprefixed/stable task IDs), that the
DailyMed/FAERS/Drugs@FDA ``extract_*`` tasks are native Go SDK stubs routed to the ``golang``
queue (the EMA parse is a plain Python task beside them), that
acquisition/extraction resource pools let those tasks run concurrently, that the two DailyMed GLiNER-mining shape tasks serialize on the 1-slot ``ner_mining`` pool,
that FAERS observed-use shaping bypasses NER, and that the GLiNER2 NER-export task runs on
the ``ner_mining`` pool AFTER the shape stage (warm mention cache), consuming the DailyMed +
FAERS + EMA extracts.
"""

from __future__ import annotations

# ``dakp_build`` (and thus ``import airflow``) is pulled in lazily via the ``dakp_build`` fixture so
# pytest-xdist workers don't pay the Airflow import during per-worker collection (see conftest.py).

_EXPECTED_TASK_IDS = {
    "acquire_dailymed",
    "acquire_faers",
    "acquire_drugsfda",
    "acquire_ema",
    "acquire_ema_smpc",
    "acquire_canada_vigilance",
    "acquire_ner_models",
    "extract_dailymed",
    "extract_faers",
    "extract_drugsfda",
    "extract_ema",
    "extract_ema_smpc",
    "extract_canada_vigilance",
    "shape_treatment_tables",
    "shape_faers_use_tables",
    "shape_contraindication_tables",
    "generate_tablassert_configs",
    "run_tablassert",
    "export_legacy_tsv",
    "publish_release_artifacts",
    "export_ner_training_data",
}

_GO_STUB_IDS = {"extract_dailymed", "extract_faers", "extract_drugsfda"}
_ACQUIRE_IDS = {
    "acquire_dailymed",
    "acquire_faers",
    "acquire_drugsfda",
    "acquire_ema",
    "acquire_ema_smpc",
    "acquire_canada_vigilance",
    "acquire_ner_models",
}
_EXPECTED_GROUP_MEMBERS = {
    "acquire": _ACQUIRE_IDS,
    "extract": _GO_STUB_IDS | {"extract_ema", "extract_ema_smpc", "extract_canada_vigilance"},
    "shape": {"shape_treatment_tables", "shape_faers_use_tables", "shape_contraindication_tables"},
    "tablassert": {"generate_tablassert_configs", "run_tablassert"},
    "export": {"export_legacy_tsv", "publish_release_artifacts"},
    "ner-export": {"export_ner_training_data"},
}


def test_module_constants(dakp_build) -> None:
    assert dakp_build.DAG_ID == "dakp_pipeline"
    assert dakp_build.GO_QUEUE == "golang"
    assert dakp_build.DOWNLOAD_POOL == "dakp_download"
    assert dakp_build.EXTRACT_POOL == "dakp_extract"
    assert dakp_build.NER_MINING_POOL == "ner_mining"
    assert dakp_build.CONFIG_VARIABLE == "dakp_config"


def test_dag_object_and_task_ids(dakp_build) -> None:
    dag = dakp_build.dag_obj
    assert dag.dag_id == "dakp_pipeline"
    assert {t.task_id for t in dag.tasks} == _EXPECTED_TASK_IDS


def test_task_groups_preserve_stable_task_ids(dakp_build) -> None:
    dag = dakp_build.dag_obj
    assert set(dag.task_group.children) == set(_EXPECTED_GROUP_MEMBERS)
    for group_id, members in _EXPECTED_GROUP_MEMBERS.items():
        grouped = {task.task_id for task in dag.tasks if task.task_group.group_id == group_id}
        assert grouped == members
    # prefix_group_id=False keeps Airflow history/log task IDs unchanged.
    assert all("." not in task.task_id for task in dag.tasks)


def test_extract_tasks_are_go_stubs_on_golang_queue(dakp_build) -> None:
    dag = dakp_build.dag_obj
    for task_id in _GO_STUB_IDS:
        task = dag.get_task(task_id)
        assert task.queue == dakp_build.GO_QUEUE
        assert task.pool == dakp_build.EXTRACT_POOL
        # Each extract costs the default 1 slot, so all three run concurrently within the 4-slot
        # pool (the streaming FAERS rewrite removed the memory pressure that weighted them 3/3/1).
        assert task.pool_slots == 1
        assert type(task).__name__ == "_StubOperator"


def test_extract_ema_is_a_python_task_in_the_extract_pool(dakp_build) -> None:
    """The EMA xlsx is small enough to parse in-process: a plain Python task, not a Go stub.

    It shares the 4-slot extract pool at the default 1 slot, so it runs beside the heavy Go
    extracts instead of serializing behind them.
    """
    task = dakp_build.dag_obj.get_task("extract_ema")
    assert task.queue != dakp_build.GO_QUEUE
    assert task.pool == dakp_build.EXTRACT_POOL
    assert task.pool_slots == 1
    assert type(task).__name__ != "_StubOperator"


def test_acquisition_tasks_use_download_pool(dakp_build) -> None:
    dag = dakp_build.dag_obj
    for task_id in _ACQUIRE_IDS:
        assert dag.get_task(task_id).pool == dakp_build.DOWNLOAD_POOL


def test_shape_tasks_use_ner_mining_pool(dakp_build) -> None:
    # DailyMed GLiNER-mining shape tasks sit on the 1-slot pool so concurrent shape tasks
    # serialize instead of oversubscribing the GPUs (the per-device flock is the backstop).
    dag = dakp_build.dag_obj
    ner_tasks = {"shape_treatment_tables", "shape_contraindication_tables"}
    for task_id in ner_tasks:
        assert dag.get_task(task_id).pool == dakp_build.NER_MINING_POOL
    # FAERS observed-use shaping performs lexical lookup and downstream intervention mapping;
    # it must not reserve the GPU/NER pool.
    assert dag.get_task("shape_faers_use_tables").pool == "default_pool"


def test_dag_task_graph(dakp_build) -> None:
    dag = dakp_build.dag_obj

    def upstream(task_id: str) -> set[str]:
        return set(dag.get_task(task_id).upstream_task_ids)

    def downstream(task_id: str) -> set[str]:
        return set(dag.get_task(task_id).downstream_task_ids)

    # Acquisition feeds its own extractor (download -> native Go extract; the EMA parses are
    # plain Python tasks fed by acquire_ema / acquire_ema_smpc).
    assert upstream("extract_dailymed") == {"acquire_dailymed"}
    assert upstream("extract_faers") == {"acquire_faers"}
    assert upstream("extract_drugsfda") == {"acquire_drugsfda"}
    assert upstream("extract_ema") == {"acquire_ema"}
    assert upstream("extract_ema_smpc") == {"acquire_ema_smpc"}
    assert upstream("extract_canada_vigilance") == {"acquire_canada_vigilance"}

    # Shapers join the extracts (treatment: dm+drugsfda+faers+ema + NER models; uses: faers+dm+drugsfda
    # + the produced approved-treats table + NER models; contraindication: dm+drugsfda+smpc+ema + NER
    # models). Every shaper takes Drugs@FDA: it is the FDA application register that expands the
    # prefix-stripped application numbers into their FDA form for FDA_regulatory_approvals.
    assert upstream("shape_treatment_tables") == {
        "extract_dailymed",
        "extract_drugsfda",
        "extract_faers",
        "extract_ema",
        "extract_ema_smpc",
        "acquire_ner_models",
    }
    assert upstream("shape_faers_use_tables") == {
        "extract_faers",
        "extract_dailymed",
        "extract_drugsfda",
        "extract_canada_vigilance",
        "shape_treatment_tables",
    }
    assert upstream("shape_contraindication_tables") == {
        "extract_dailymed",
        "extract_drugsfda",
        "extract_ema",
        "extract_ema_smpc",
        "acquire_ner_models",
    }

    shapes = {"shape_treatment_tables", "shape_faers_use_tables", "shape_contraindication_tables"}
    assert upstream("generate_tablassert_configs") == shapes
    assert upstream("run_tablassert") == shapes | {"generate_tablassert_configs"}
    # The legacy TSV export consumes the handoff (its report ref tells it real vs deferred).
    assert upstream("export_legacy_tsv") == {"run_tablassert"}
    # The release publish joins the KGX handoff and the legacy TSV pair (the RIG it renames is a
    # build-kg output, not a config) — and is a leaf (nothing downstream waits on the artifacts).
    assert upstream("publish_release_artifacts") == {"run_tablassert", "export_legacy_tsv"}
    assert downstream("publish_release_artifacts") == set()

    # The NER export consumes the DailyMed + FAERS + EMA extracts, orders after model
    # acquisition (GLiNER weights cached) and after the shape stage (whose mining warms the
    # mention cache the export's own GLiNER inference then hits), and is a leaf: nothing
    # downstream waits on the bundle.
    assert upstream("export_ner_training_data") == {
        "extract_dailymed",
        "extract_faers",
        "extract_ema",
        "acquire_ner_models",
        "shape_contraindication_tables",
    }
    assert downstream("export_ner_training_data") == set()


def test_ner_export_task_uses_the_ner_pool(dakp_build) -> None:
    """The export runs GLiNER inference, so it shares the 1-slot ``ner_mining`` pool with the
    other GLiNER consumers instead of competing for the GPUs unbounded."""
    assert dakp_build.dag_obj.get_task("export_ner_training_data").pool == "ner_mining"


# --- stall-recovery budgets ---------------------------------------------------------


def test_stall_recovery_budgets(dakp_build) -> None:
    """Every task is bounded by an execution timeout and retries once; the run itself is capped.

    The unbounded-DAG failure mode is recorded history: an orphaned task ran for hours while
    ``dakp up``'s poll loop had already given up, and nothing ever reaped it. Shaping gets the
    8 h headroom (cold contraindication mining is ~3.5 h on four P100s); everything else sits at
    the 2 h default (acquisition tightens to 1 h). A retried task resumes from the two-tier NER
    cache instead of re-mining completed work.
    """
    from datetime import timedelta

    dag = dakp_build.dag_obj
    assert dag.dagrun_timeout == timedelta(hours=12)
    assert {t.task_id for t in dag.tasks} == _EXPECTED_TASK_IDS
    for task in dag.tasks:
        assert task.retries == 1, task.task_id
        assert task.execution_timeout is not None, task.task_id
    tasks = {t.task_id: t for t in dag.tasks}
    assert tasks["acquire_dailymed"].execution_timeout == timedelta(hours=1)
    for task_id in ("shape_treatment_tables", "shape_faers_use_tables", "shape_contraindication_tables", "export_ner_training_data"):
        assert tasks[task_id].execution_timeout == timedelta(hours=8), task_id
    assert tasks["run_tablassert"].execution_timeout == timedelta(hours=2)
    assert tasks["extract_dailymed"].execution_timeout == timedelta(hours=2)
